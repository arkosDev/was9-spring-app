package com.empresa.xmltools;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.stream.Collectors;

public class XmlOneLine {

    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
        String contenido = reader.lines().collect(Collectors.joining("\n"));

        String oneLine = contenido
                .replaceAll("\\r?\\n", "")
                .replaceAll(">\\s+<", "><")
                .trim();

        System.out.println(oneLine);
    }
}
