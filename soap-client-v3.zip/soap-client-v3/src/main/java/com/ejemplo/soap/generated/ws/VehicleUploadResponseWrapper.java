package com.ejemplo.soap.generated.ws;

import com.ejemplo.soap.generated.VehicleUploadResponse;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * Wrapper manual del namespace "http://webservices" para la respuesta.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {"vehicleUploadResponse"})
@XmlRootElement(
    name      = "vehicleUploadResponse",
    namespace = "http://webservices"
)
public class VehicleUploadResponseWrapper {

    @XmlElement(
        name      = "vehicleUploadResponse",
        namespace = "http://www.tcs.com/BancsAPIWebservices/BancsAPIWebservices",
        required  = true
    )
    private VehicleUploadResponse vehicleUploadResponse;

    public VehicleUploadResponse getVehicleUploadResponse() {
        return vehicleUploadResponse;
    }

    public void setVehicleUploadResponse(VehicleUploadResponse vehicleUploadResponse) {
        this.vehicleUploadResponse = vehicleUploadResponse;
    }
}
