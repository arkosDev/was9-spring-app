package com.ejemplo.soap;

import com.ejemplo.soap.generated.VehicleUploadRequest;
import com.ejemplo.soap.generated.VehicleUploadResponse;
import com.ejemplo.soap.service.VehicleUploadService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class SoapClientApp {

    public static void main(String[] args) {
        SpringApplication.run(SoapClientApp.class, args);
    }

    @Bean
    CommandLineRunner run(VehicleUploadService service) {
        return args -> {
            VehicleUploadRequest request = new VehicleUploadRequest();
            request.setMarca("TOYOTA");
            request.setModelo("2024");
            request.setCveveh("TST001");
            request.setDescripcion("COROLLA LE");
            request.setTransmision("A");
            request.setCombustible("G");

            VehicleUploadResponse response = service.uploadVehicle(request);
            System.out.println("responseCode:    " + response.getResponseCode());
            System.out.println("responseMessage: " + response.getResponseMessage());
        };
    }
}
