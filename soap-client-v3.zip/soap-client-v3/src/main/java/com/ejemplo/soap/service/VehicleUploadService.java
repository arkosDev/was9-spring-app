package com.ejemplo.soap.service;

import com.ejemplo.soap.generated.VehicleUploadRequest;
import com.ejemplo.soap.generated.VehicleUploadResponse;
import com.ejemplo.soap.generated.ws.VehicleUploadRequestWrapper;
import com.ejemplo.soap.generated.ws.VehicleUploadResponseWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ws.client.core.WebServiceTemplate;

@Service
public class VehicleUploadService {

    @Autowired
    private WebServiceTemplate webServiceTemplate;

    public VehicleUploadResponse uploadVehicle(VehicleUploadRequest bancsRequest) {

        // Envolver en el envelope del namespace "webservices"
        VehicleUploadRequestWrapper wrapper = new VehicleUploadRequestWrapper();
        wrapper.setVehicleUploadRequest(bancsRequest);

        VehicleUploadResponseWrapper responseWrapper =
            (VehicleUploadResponseWrapper)
                webServiceTemplate.marshalSendAndReceive(wrapper);

        return responseWrapper.getVehicleUploadResponse();
    }
}
