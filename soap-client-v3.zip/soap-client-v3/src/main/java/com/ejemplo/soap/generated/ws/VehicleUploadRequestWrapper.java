package com.ejemplo.soap.generated.ws;

import com.ejemplo.soap.generated.VehicleUploadRequest;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * Wrapper manual del namespace "http://webservices" (equivale al xsd2).
 * Es el elemento raiz que el servidor SOAP espera recibir.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {"vehicleUploadRequest"})
@XmlRootElement(
    name      = "vehicleUploadRequest",
    namespace = "http://webservices"
)
public class VehicleUploadRequestWrapper {

    @XmlElement(
        name      = "vehicleUploadRequest",
        namespace = "http://www.tcs.com/BancsAPIWebservices/BancsAPIWebservices",
        required  = true
    )
    private VehicleUploadRequest vehicleUploadRequest;

    public VehicleUploadRequest getVehicleUploadRequest() {
        return vehicleUploadRequest;
    }

    public void setVehicleUploadRequest(VehicleUploadRequest vehicleUploadRequest) {
        this.vehicleUploadRequest = vehicleUploadRequest;
    }
}
