package com.ejemplo.soap.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.ws.client.core.WebServiceTemplate;

@Configuration
public class SoapClientConfig {

    @Value("${vehicle.ws.url:http://10.77.5.75:7850/BancsAPIWebservices/VehicleUploadWS}")
    private String vehicleWsUrl;

    @Bean
    public Jaxb2Marshaller marshaller() {
        Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
        marshaller.setContextPaths(
            "com.ejemplo.soap.generated",     // clases generadas de xsd1
            "com.ejemplo.soap.generated.ws"   // wrappers manuales del namespace webservices
        );
        return marshaller;
    }

    @Bean
    public WebServiceTemplate webServiceTemplate(Jaxb2Marshaller marshaller) {
        WebServiceTemplate template = new WebServiceTemplate();
        template.setMarshaller(marshaller);
        template.setUnmarshaller(marshaller);
        template.setDefaultUri(vehicleWsUrl);
        return template;
    }
}
