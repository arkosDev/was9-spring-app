<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="es">
<head><meta charset="UTF-8"><title>No autorizado</title></head>
<body>
<h2>403 - No autorizado</h2>
<p>No tienes permiso para acceder a este recurso.</p>
<a href="<%= request.getContextPath() %>/login.do">Ir al login</a>
</body>
</html>
