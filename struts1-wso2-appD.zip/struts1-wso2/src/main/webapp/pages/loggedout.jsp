<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Sesion cerrada</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }
        .card { background: white; padding: 30px; border-radius: 8px;
                box-shadow: 0 2px 6px rgba(0,0,0,0.15); max-width: 500px; }
        a.btn { display: inline-block; margin-top: 20px; padding: 10px 24px;
                background: #27ae60; color: white; text-decoration: none;
                border-radius: 4px; }
    </style>
</head>
<body>
<div class="card">
    <h1>&#128274; Sesion cerrada</h1>
    <p>Tu sesion ha sido cerrada correctamente en la aplicacion y en WSO2 Identity Server.</p>
    <a href="<%= request.getContextPath() %>/login.do" class="btn">Iniciar sesion nuevamente</a>
</div>
</body>
</html>
