<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%-- 
    Esta pagina recibe la URL de WSO2 y hace el redirect.
    Usar JavaScript para manejar URLs largas con PKCE.
--%>
<%
    String authUrl = (String) request.getAttribute("authorizationUrl");
    if (authUrl == null) {
        response.sendRedirect(request.getContextPath() + "/pages/error.jsp?msg=no_auth_url");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Redirigiendo a WSO2 IS...</title>
</head>
<body>
    <p>Redirigiendo al servidor de autenticacion...</p>
    <script type="text/javascript">
        window.location.href = '<%= authUrl.replace("'", "\\'") %>';
    </script>
    <noscript>
        <a href="<%= authUrl %>">Haz clic aqui para continuar</a>
    </noscript>
</body>
</html>
