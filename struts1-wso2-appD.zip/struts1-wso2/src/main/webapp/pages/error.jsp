<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Error</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }
        .card { background: white; padding: 30px; border-radius: 8px;
                box-shadow: 0 2px 6px rgba(0,0,0,0.15); max-width: 500px; }
        h1 { color: #c0392b; }
        a { color: #2980b9; }
    </style>
</head>
<body>
<div class="card">
    <h1>Error de autenticacion</h1>
    <p>Ocurrio un error durante el proceso de autenticacion con WSO2 IS.</p>
    <% String msg = request.getParameter("msg");
       if (msg != null && !msg.isEmpty()) { %>
        <p><strong>Detalle:</strong> <%= msg %></p>
    <% } %>
    <p><a href="<%= request.getContextPath() %>/login.do">Intentar de nuevo</a></p>
</div>
</body>
</html>
