<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%-- Redirige automaticamente al action de login --%>
<jsp:forward page="/login.do"/>
