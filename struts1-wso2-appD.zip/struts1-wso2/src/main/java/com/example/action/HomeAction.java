package com.example.action;

import com.example.util.OidcConstants;
import com.example.util.UserSession;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Action del home privado. 
 * El AuthFilter ya garantiza que solo llegan usuarios autenticados.
 * Este Action pasa el UserSession al JSP.
 */
public class HomeAction extends Action {

    @Override
    public ActionForward execute(ActionMapping mapping, ActionForm form,
                                 HttpServletRequest request, HttpServletResponse response)
            throws Exception {

        HttpSession session = request.getSession(false);
        UserSession user = null;
        if (session != null) {
            user = (UserSession) session.getAttribute(OidcConstants.SESSION_USER);
        }

        if (user == null) {
            return mapping.findForward("unauthorized");
        }

        // Exponer el usuario al JSP
        request.setAttribute("user", user);
        return mapping.findForward("success");
    }
}
