package com.example.action;

import com.example.listener.AppContextListener;
import com.example.service.OidcService;
import com.example.util.OidcConstants;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LoginAction extends Action {

    private static final Logger log = LoggerFactory.getLogger(LoginAction.class);

    @Override
    public ActionForward execute(ActionMapping mapping, ActionForm form,
                                 HttpServletRequest request, HttpServletResponse response)
            throws Exception {

        HttpSession session = request.getSession(true);

        if (session.getAttribute(OidcConstants.SESSION_USER) != null) {
            response.sendRedirect(request.getContextPath() + "/secure/home.do");
            return null;
        }

        OidcService oidcService = (OidcService) getServlet()
                .getServletContext().getAttribute(AppContextListener.OIDC_SERVICE);

        String codeVerifier  = oidcService.generateCodeVerifier();
        String codeChallenge = oidcService.generateCodeChallenge(codeVerifier);
        String state         = oidcService.generateState();

        session.setAttribute(OidcConstants.SESSION_CODE_VERIFIER, codeVerifier);
        session.setAttribute(OidcConstants.SESSION_STATE, state);

        String authUrl = oidcService.buildAuthorizationUrl(state, codeChallenge);
        log.debug("Redirigiendo a WSO2 IS: {}", authUrl);

        request.setAttribute("authorizationUrl", authUrl);
        return mapping.findForward("redirect");
    }
}
