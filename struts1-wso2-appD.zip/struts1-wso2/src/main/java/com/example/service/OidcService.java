package com.example.service;

import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.jwk.source.JWKSource;
import com.nimbusds.jose.jwk.source.RemoteJWKSet;
import com.nimbusds.jose.proc.JWSKeySelector;
import com.nimbusds.jose.proc.JWSVerificationKeySelector;
import com.nimbusds.jose.proc.SimpleSecurityContext;
import com.nimbusds.jwt.JWT;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.proc.ConfigurableJWTProcessor;
import com.nimbusds.jwt.proc.DefaultJWTProcessor;
import net.minidev.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.net.ssl.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Map;

/**
 * Servicio OIDC que encapsula la comunicacion con WSO2 IS.
 * Implementa Authorization Code Flow con client_secret (Basic Auth en token endpoint).
 * Compatible con JDK 1.7 y Nimbus JOSE+JWT 4.x.
 */
public class OidcService {

    private static final Logger log = LoggerFactory.getLogger(OidcService.class);

    // Inyectados por Spring desde oidc.properties
    private String clientId;
    private String clientSecret;
    private String redirectUri;
    private String authorizationEndpoint;
    private String tokenEndpoint;
    private String userinfoEndpoint;
    private String endSessionEndpoint;
    private String jwksUri;
    private String scope;
    private boolean sslVerify = true;

    // ===================================================
    // PKCE helpers
    // ===================================================

    /**
     * Genera un code_verifier aleatorio (43-128 chars, RFC 7636).
     */
    public String generateCodeVerifier() {
        SecureRandom sr = new SecureRandom();
        byte[] bytes = new byte[32];
        sr.nextBytes(bytes);
        return base64UrlEncode(bytes);
    }

    /**
     * Calcula code_challenge = BASE64URL(SHA-256(code_verifier)).
     */
    public String generateCodeChallenge(String codeVerifier) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(codeVerifier.getBytes("US-ASCII"));
        return base64UrlEncode(hash);
    }

    /**
     * Genera un state aleatorio para prevenir CSRF.
     */
    public String generateState() {
        SecureRandom sr = new SecureRandom();
        byte[] bytes = new byte[16];
        sr.nextBytes(bytes);
        return base64UrlEncode(bytes);
    }

    // ===================================================
    // Authorization URL
    // ===================================================

    /**
     * Construye la URL de autorizacion hacia WSO2 IS.
     * El navegador redirigira al usuario aqui para autenticarse.
     */
    public String buildAuthorizationUrl(String state, String codeChallenge) throws Exception {
        StringBuilder sb = new StringBuilder(authorizationEndpoint);
        sb.append("?response_type=code");
        sb.append("&client_id=").append(URLEncoder.encode(clientId, "UTF-8"));
        sb.append("&redirect_uri=").append(URLEncoder.encode(redirectUri, "UTF-8"));
        sb.append("&scope=").append(URLEncoder.encode(scope, "UTF-8"));
        sb.append("&state=").append(URLEncoder.encode(state, "UTF-8"));
        sb.append("&code_challenge=").append(URLEncoder.encode(codeChallenge, "UTF-8"));
        sb.append("&code_challenge_method=S256");
        return sb.toString();
    }

    // ===================================================
    // Token Exchange
    // ===================================================

    /**
     * Intercambia el authorization_code por tokens en el token endpoint.
     * Retorna un mapa con access_token, id_token, refresh_token.
     */
    public Map<String, String> exchangeCodeForTokens(String code, String codeVerifier) throws Exception {
        // Body: solo parametros OAuth basicos (sin client_id/secret en body, van en Basic Auth)
        String body = "grant_type=authorization_code"
                + "&code=" + URLEncoder.encode(code, "UTF-8")
                + "&redirect_uri=" + URLEncoder.encode(redirectUri, "UTF-8");

        // code_verifier solo si se uso PKCE (opcional con secret)
        if (codeVerifier != null && !codeVerifier.isEmpty()) {
            body += "&code_verifier=" + URLEncoder.encode(codeVerifier, "UTF-8");
        }

        String response = doPostWithBasicAuth(tokenEndpoint, body);
        log.debug("Token endpoint response: {}", response);

        return parseJsonToMap(response);
    }

    // ===================================================
    // Userinfo
    // ===================================================

    /**
     * Llama al userinfo endpoint con el access_token.
     * Retorna los claims del usuario (sub, name, email, preferred_username, etc.)
     */
    public Map<String, Object> getUserInfo(String accessToken) throws Exception {
        URL url = new URL(userinfoEndpoint);
        HttpURLConnection conn = openConnection(url);
        conn.setRequestMethod("GET");
        conn.setRequestProperty("Authorization", "Bearer " + accessToken);
        conn.setRequestProperty("Accept", "application/json");

        int status = conn.getResponseCode();
        if (status != 200) {
            throw new RuntimeException("Userinfo endpoint devolvio HTTP " + status);
        }

        String response = readResponse(conn);
        log.debug("Userinfo response: {}", response);

        return parseJsonToObjectMap(response);
    }

    // ===================================================
    // ID Token validation (Nimbus)
    // ===================================================

    /**
     * Valida el id_token contra la JWKS de WSO2 IS.
     * Retorna los claims del JWT si es valido.
     */
    public JWTClaimsSet validateIdToken(String idToken) throws Exception {
        ConfigurableJWTProcessor<SimpleSecurityContext> jwtProcessor =
                new DefaultJWTProcessor<SimpleSecurityContext>();

        JWKSource<SimpleSecurityContext> jwkSource =
                new RemoteJWKSet<SimpleSecurityContext>(new URL(jwksUri));

        JWSKeySelector<SimpleSecurityContext> keySelector =
                new JWSVerificationKeySelector<SimpleSecurityContext>(
                        JWSAlgorithm.RS256, jwkSource);

        jwtProcessor.setJWSKeySelector(keySelector);

        JWTClaimsSet claims = jwtProcessor.process(idToken, null);
        log.debug("ID Token claims: {}", claims.toJSONObject());
        return claims;
    }

    // ===================================================
    // Logout URL
    // ===================================================

    /**
     * Construye la URL de end_session hacia WSO2 IS.
     */
    public String buildLogoutUrl(String idTokenHint, String postLogoutRedirectUri) throws Exception {
        StringBuilder sb = new StringBuilder(endSessionEndpoint);
        sb.append("?id_token_hint=").append(URLEncoder.encode(idTokenHint, "UTF-8"));
        if (postLogoutRedirectUri != null) {
            sb.append("&post_logout_redirect_uri=")
              .append(URLEncoder.encode(postLogoutRedirectUri, "UTF-8"));
        }
        return sb.toString();
    }

    // ===================================================
    // HTTP helpers
    // ===================================================

    /**
     * POST al token endpoint con HTTP Basic Auth (client_id:client_secret en Base64).
     * Esta es la forma estandar para confidential clients en OAuth 2.0 / WSO2 IS.
     */
    private String doPostWithBasicAuth(String endpoint, String body) throws Exception {
        URL url = new URL(endpoint);
        HttpURLConnection conn = openConnection(url);
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        conn.setRequestProperty("Accept", "application/json");

        // Basic Auth: Base64(clientId:clientSecret)
        String credentials = clientId + ":" + clientSecret;
        String encoded = javax.xml.bind.DatatypeConverter.printBase64Binary(
                credentials.getBytes("UTF-8"));
        conn.setRequestProperty("Authorization", "Basic " + encoded);

        OutputStream os = conn.getOutputStream();
        os.write(body.getBytes("UTF-8"));
        os.flush();
        os.close();

        int status = conn.getResponseCode();
        if (status < 200 || status >= 300) {
            String err = readErrorResponse(conn);
            throw new RuntimeException("Token endpoint HTTP " + status + ": " + err);
        }

        return readResponse(conn);
    }

        private String doPost(String endpoint, String body, String contentType) throws Exception {
        URL url = new URL(endpoint);
        HttpURLConnection conn = openConnection(url);
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        conn.setRequestProperty("Content-Type", contentType);
        conn.setRequestProperty("Accept", "application/json");

        OutputStream os = conn.getOutputStream();
        os.write(body.getBytes("UTF-8"));
        os.flush();
        os.close();

        int status = conn.getResponseCode();
        if (status < 200 || status >= 300) {
            String err = readErrorResponse(conn);
            throw new RuntimeException("Token endpoint HTTP " + status + ": " + err);
        }

        return readResponse(conn);
    }

    private HttpURLConnection openConnection(URL url) throws Exception {
        HttpURLConnection conn;
        if ("https".equals(url.getProtocol()) && !sslVerify) {
            conn = (HttpURLConnection) url.openConnection(java.net.Proxy.NO_PROXY);
            // Disable SSL verification for self-signed certs (WSO2 local)
            HttpsURLConnection httpsConn = (HttpsURLConnection) conn;
            httpsConn.setSSLSocketFactory(getTrustAllSslFactory());
            httpsConn.setHostnameVerifier(new HostnameVerifier() {
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            });
        } else {
            conn = (HttpURLConnection) url.openConnection();
        }
        conn.setConnectTimeout(10000);
        conn.setReadTimeout(15000);
        return conn;
    }

    private SSLSocketFactory getTrustAllSslFactory() throws Exception {
        TrustManager[] trustAll = new TrustManager[]{
            new X509TrustManager() {
                public X509Certificate[] getAcceptedIssuers() { return null; }
                public void checkClientTrusted(X509Certificate[] c, String a) {}
                public void checkServerTrusted(X509Certificate[] c, String a) {}
            }
        };
        SSLContext sc = SSLContext.getInstance("TLS");
        sc.init(null, trustAll, new SecureRandom());
        return sc.getSocketFactory();
    }

    private String readResponse(HttpURLConnection conn) throws Exception {
        BufferedReader br = new BufferedReader(
                new InputStreamReader(conn.getInputStream(), "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        return sb.toString();
    }

    private String readErrorResponse(HttpURLConnection conn) {
        try {
            BufferedReader br = new BufferedReader(
                    new InputStreamReader(conn.getErrorStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close();
            return sb.toString();
        } catch (Exception e) {
            return "(no error body)";
        }
    }

    // ===================================================
    // JSON helpers (con json-smart 1.x, compat JDK7)
    // ===================================================

    @SuppressWarnings("unchecked")
    private Map<String, String> parseJsonToMap(String json) {
        net.minidev.json.parser.JSONParser parser =
                new net.minidev.json.parser.JSONParser(
                        net.minidev.json.parser.JSONParser.MODE_JSON_SIMPLE);
        try {
            JSONObject obj = (JSONObject) parser.parse(json);
            Map<String, String> map = new HashMap<String, String>();
            for (Map.Entry<String, Object> entry : obj.entrySet()) {
                if (entry.getValue() != null) {
                    map.put(entry.getKey(), entry.getValue().toString());
                }
            }
            return map;
        } catch (Exception e) {
            throw new RuntimeException("Error parseando JSON: " + json, e);
        }
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> parseJsonToObjectMap(String json) {
        net.minidev.json.parser.JSONParser parser =
                new net.minidev.json.parser.JSONParser(
                        net.minidev.json.parser.JSONParser.MODE_JSON_SIMPLE);
        try {
            JSONObject obj = (JSONObject) parser.parse(json);
            Map<String, Object> map = new HashMap<String, Object>();
            map.putAll(obj);
            return map;
        } catch (Exception e) {
            throw new RuntimeException("Error parseando JSON: " + json, e);
        }
    }

    // ===================================================
    // Util: BASE64URL sin padding (RFC 7636)
    // ===================================================

    private String base64UrlEncode(byte[] bytes) {
        // Java 7 no tiene java.util.Base64 → implementacion manual
        String b64 = javax.xml.bind.DatatypeConverter.printBase64Binary(bytes);
        // Convertir a URL-safe y remover padding
        return b64.replace('+', '-').replace('/', '_').replaceAll("=+$", "");
    }

    // ===================================================
    // Setters (inyeccion Spring)
    // ===================================================

    public void setClientId(String clientId) { this.clientId = clientId; }
    public void setClientSecret(String clientSecret) { this.clientSecret = clientSecret; }
    public void setRedirectUri(String redirectUri) { this.redirectUri = redirectUri; }
    public void setAuthorizationEndpoint(String authorizationEndpoint) {
        this.authorizationEndpoint = authorizationEndpoint;
    }
    public void setTokenEndpoint(String tokenEndpoint) { this.tokenEndpoint = tokenEndpoint; }
    public void setUserinfoEndpoint(String userinfoEndpoint) {
        this.userinfoEndpoint = userinfoEndpoint;
    }
    public void setEndSessionEndpoint(String endSessionEndpoint) {
        this.endSessionEndpoint = endSessionEndpoint;
    }
    public void setJwksUri(String jwksUri) { this.jwksUri = jwksUri; }
    public void setScope(String scope) { this.scope = scope; }
    public void setSslVerify(boolean sslVerify) { this.sslVerify = sslVerify; }
    public String getEndSessionEndpoint() { return endSessionEndpoint; }
    public String getClientId() { return clientId; }
    public String getRedirectUri() { return redirectUri; }
}
