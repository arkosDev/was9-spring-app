package com.example.util;

/**
 * Constantes para el flujo OIDC.
 */
public final class OidcConstants {

    private OidcConstants() {}

    /** Clave en sesion HTTP donde se guarda el UserSession. */
    public static final String SESSION_USER = "OIDC_USER";

    /** Clave en sesion HTTP donde se guarda el code_verifier PKCE. */
    public static final String SESSION_CODE_VERIFIER = "OIDC_CODE_VERIFIER";

    /** Clave en sesion HTTP donde se guarda el state anti-CSRF. */
    public static final String SESSION_STATE = "OIDC_STATE";
}
