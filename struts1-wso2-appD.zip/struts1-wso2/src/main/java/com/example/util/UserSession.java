package com.example.util;

import java.io.Serializable;
import java.util.Map;

/**
 * Objeto de sesion que almacena los datos del usuario autenticado via OIDC.
 * Se guarda en HttpSession bajo la clave OidcConstants.SESSION_USER.
 */
public class UserSession implements Serializable {

    private static final long serialVersionUID = 1L;

    private String sub;               // Subject (identificador unico en WSO2)
    private String name;
    private String email;
    private String preferredUsername;
    private String accessToken;
    private String idToken;           // para el logout (id_token_hint)
    private Map<String, Object> allClaims; // todos los claims del userinfo

    public String getSub() { return sub; }
    public void setSub(String sub) { this.sub = sub; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPreferredUsername() { return preferredUsername; }
    public void setPreferredUsername(String preferredUsername) {
        this.preferredUsername = preferredUsername;
    }

    public String getAccessToken() { return accessToken; }
    public void setAccessToken(String accessToken) { this.accessToken = accessToken; }

    public String getIdToken() { return idToken; }
    public void setIdToken(String idToken) { this.idToken = idToken; }

    public Map<String, Object> getAllClaims() { return allClaims; }
    public void setAllClaims(Map<String, Object> allClaims) { this.allClaims = allClaims; }
}
