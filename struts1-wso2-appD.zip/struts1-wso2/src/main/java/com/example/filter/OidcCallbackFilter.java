package com.example.filter;

import com.example.listener.AppContextListener;
import com.example.service.OidcService;
import com.example.util.OidcConstants;
import com.example.util.UserSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Map;

public class OidcCallbackFilter implements Filter {

    private static final Logger log = LoggerFactory.getLogger(OidcCallbackFilter.class);

    private ServletContext servletContext;

    @Override
    public void init(FilterConfig cfg) throws ServletException {
        this.servletContext = cfg.getServletContext();
        log.info("OidcCallbackFilter inicializado");
    }

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest  request  = (HttpServletRequest)  req;
        HttpServletResponse response = (HttpServletResponse) res;
        HttpSession session = request.getSession(false);

        String code  = request.getParameter("code");
        String state = request.getParameter("state");
        String error = request.getParameter("error");

        log.info("=== CALLBACK recibido ===");
        log.info("  code  = {}", code  != null ? code.substring(0, Math.min(20, code.length())) + "..." : "NULL");
        log.info("  state = {}", state);
        log.info("  error = {}", error);
        log.info("  session existe = {}", session != null);

        if (error != null) {
            log.warn("WSO2 devolvio error: {}", error);
            response.sendRedirect(request.getContextPath() + "/pages/error.jsp?msg=" + error);
            return;
        }

        if (code == null || state == null) {
            log.error("PASO 0 FALLO: code o state es null");
            response.sendRedirect(request.getContextPath() + "/pages/error.jsp?msg=bad_callback");
            return;
        }

        if (session == null) {
            log.error("PASO 0 FALLO: no hay sesion activa");
            response.sendRedirect(request.getContextPath() + "/login.do");
            return;
        }

        String savedState   = (String) session.getAttribute(OidcConstants.SESSION_STATE);
        String codeVerifier = (String) session.getAttribute(OidcConstants.SESSION_CODE_VERIFIER);

        log.info("  savedState   = {}", savedState);
        log.info("  codeVerifier = {}", codeVerifier != null ? codeVerifier.substring(0, 10) + "..." : "NULL");

        if (!state.equals(savedState)) {
            log.error("PASO 1 FALLO: state mismatch. esperado={} recibido={}", savedState, state);
            response.sendRedirect(request.getContextPath() + "/pages/error.jsp?msg=state_mismatch");
            return;
        }
        log.info("PASO 1 OK: state valido");

        try {
            OidcService oidcService = (OidcService) servletContext.getAttribute(AppContextListener.OIDC_SERVICE);

            // PASO 2: intercambiar code por tokens
            log.info("PASO 2: llamando token endpoint...");
            Map<String, String> tokens = oidcService.exchangeCodeForTokens(code, codeVerifier);
            log.info("PASO 2 OK: tokens recibidos = {}", tokens.keySet());

            String accessToken = tokens.get("access_token");
            String idToken     = tokens.get("id_token");

            log.info("  access_token = {}", accessToken != null ? accessToken.substring(0, Math.min(30, accessToken.length())) + "..." : "NULL");
            log.info("  id_token     = {}", idToken     != null ? idToken.substring(0, Math.min(30, idToken.length()))     + "..." : "NULL");

            if (accessToken == null) {
                log.error("PASO 2 FALLO: no vino access_token. Respuesta completa: {}", tokens);
                throw new RuntimeException("Token endpoint no devolvio access_token");
            }

            // PASO 3: obtener userinfo
            log.info("PASO 3: llamando userinfo endpoint...");
            Map<String, Object> userInfo = oidcService.getUserInfo(accessToken);
            log.info("PASO 3 OK: claims recibidos = {}", userInfo.keySet());
            log.info("  sub   = {}", userInfo.get("sub"));
            log.info("  email = {}", userInfo.get("email"));

            // PASO 4: construir sesion
            log.info("PASO 4: construyendo sesion de usuario...");
            UserSession userSession = new UserSession();
            userSession.setSub(               getString(userInfo, "sub"));
            userSession.setName(              getString(userInfo, "name"));
            userSession.setEmail(             getString(userInfo, "email"));
            userSession.setPreferredUsername( getString(userInfo, "preferred_username"));
            userSession.setAccessToken(accessToken);
            userSession.setIdToken(idToken);
            userSession.setAllClaims(userInfo);

            session.setAttribute(OidcConstants.SESSION_USER, userSession);
            session.removeAttribute(OidcConstants.SESSION_CODE_VERIFIER);
            session.removeAttribute(OidcConstants.SESSION_STATE);

            log.info("PASO 4 OK: usuario autenticado sub={} user={}",
                    userSession.getSub(), userSession.getPreferredUsername());

            response.sendRedirect(request.getContextPath() + "/secure/home.do");

        } catch (Exception e) {
            log.error("!!!! FALLO en callback: {}", e.getMessage(), e);
            response.sendRedirect(request.getContextPath() + "/pages/error.jsp?msg=callback_error");
        }
    }

    @Override
    public void destroy() {}

    private String getString(Map<String, Object> map, String key) {
        Object val = map.get(key);
        return val != null ? val.toString() : null;
    }
}
