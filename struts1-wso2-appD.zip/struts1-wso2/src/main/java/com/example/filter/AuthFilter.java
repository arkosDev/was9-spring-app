package com.example.filter;

import com.example.util.OidcConstants;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * Filtro que verifica que el usuario este autenticado para acceder a /secure/*.
 * Si no hay sesion valida, redirige al login OIDC.
 */
public class AuthFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {}

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest  request  = (HttpServletRequest)  req;
        HttpServletResponse response = (HttpServletResponse) res;

        HttpSession session = request.getSession(false);
        boolean authenticated = session != null
                && session.getAttribute(OidcConstants.SESSION_USER) != null;

        if (!authenticated) {
            response.sendRedirect(request.getContextPath() + "/login.do");
            return;
        }

        chain.doFilter(req, res);
    }

    @Override
    public void destroy() {}
}
