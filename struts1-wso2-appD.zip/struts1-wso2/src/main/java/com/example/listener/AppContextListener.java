package com.example.listener;

import com.example.service.OidcService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import java.io.InputStream;
import java.util.Properties;

/**
 * Listener que crea e inicializa el OidcService al arrancar la aplicacion
 * y lo guarda en ServletContext. Reemplaza Spring sin ningún framework extra.
 */
public class AppContextListener implements ServletContextListener {

    private static final Logger log = LoggerFactory.getLogger(AppContextListener.class);

    public static final String OIDC_SERVICE = "oidcService";

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        ServletContext ctx = sce.getServletContext();
        try {
            Properties props = loadProperties(ctx, "/WEB-INF/oidc.properties");

            OidcService svc = new OidcService();
            svc.setClientId(             props.getProperty("oidc.clientId"));
            svc.setClientSecret(         props.getProperty("oidc.clientSecret"));
            svc.setRedirectUri(          props.getProperty("oidc.redirectUri"));
            svc.setAuthorizationEndpoint(props.getProperty("oidc.authorizationEndpoint"));
            svc.setTokenEndpoint(        props.getProperty("oidc.tokenEndpoint"));
            svc.setUserinfoEndpoint(     props.getProperty("oidc.userinfoEndpoint"));
            svc.setEndSessionEndpoint(   props.getProperty("oidc.endSessionEndpoint"));
            svc.setJwksUri(              props.getProperty("oidc.jwksUri"));
            svc.setScope(                props.getProperty("oidc.scope"));
            svc.setSslVerify(            Boolean.parseBoolean(
                                             props.getProperty("oidc.sslVerify", "true")));

            ctx.setAttribute(OIDC_SERVICE, svc);
            log.info("OidcService inicializado. clientId={}", svc.getClientId());

        } catch (Exception e) {
            throw new RuntimeException("Error inicializando OidcService", e);
        }
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        sce.getServletContext().removeAttribute(OIDC_SERVICE);
    }

    private Properties loadProperties(ServletContext ctx, String path) throws Exception {
        InputStream is = ctx.getResourceAsStream(path);
        if (is == null) throw new RuntimeException("No se encontro: " + path);
        Properties props = new Properties();
        props.load(is);
        is.close();
        return props;
    }
}
