package com.example.ws;

import com.example.model.Persona;
import com.example.service.PersonaService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.namespace.QName;
import javax.xml.transform.Source;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.ArrayList;
import java.util.List;

/**
 * Endpoint Spring-WS.
 * Nota: dado que el XSD no tiene clases JAXB generadas (no se corre XJC en build),
 * se parsea el DOM directamente.  Si querés generar clases JAXB, agrega el plugin
 * jaxb2-maven-plugin al pom.xml apuntando al XSD.
 */
@Endpoint
public class PersonaEndpoint {

    private static final Logger log = LoggerFactory.getLogger(PersonaEndpoint.class);
    private static final String NS = "http://example.com/soap/persona";

    private PersonaService personaService;

    public void setPersonaService(PersonaService personaService) {
        this.personaService = personaService;
    }

    // -------------------------------------------------------
    // getPersonaById
    // -------------------------------------------------------
    @PayloadRoot(namespace = NS, localPart = "getPersonaByIdRequest")
    @ResponsePayload
    public Source getPersonaById(@RequestPayload Source request) throws Exception {
        log.info("SOAP getPersonaById");

        int id = extractInt(request, "id");
        Persona p = personaService.getPersonaById(id);

        Document doc = newDocument();
        Element resp = doc.createElementNS(NS, "getPersonaByIdResponse");
        if (p != null) {
            resp.appendChild(buildPersonaElement(doc, p));
        }
        doc.appendChild(resp);
        return new DOMSource(doc);
    }

    // -------------------------------------------------------
    // getAllPersonas
    // -------------------------------------------------------
    @PayloadRoot(namespace = NS, localPart = "getAllPersonasRequest")
    @ResponsePayload
    public Source getAllPersonas(@RequestPayload Source request) throws Exception {
        log.info("SOAP getAllPersonas");

        List<Persona> lista = personaService.getAllPersonas();

        Document doc = newDocument();
        Element resp = doc.createElementNS(NS, "getAllPersonasResponse");
        for (Persona p : lista) {
            resp.appendChild(buildPersonaElement(doc, p));
        }
        doc.appendChild(resp);
        return new DOMSource(doc);
    }

    // -------------------------------------------------------
    // savePersona
    // -------------------------------------------------------
    @PayloadRoot(namespace = NS, localPart = "savePersonaRequest")
    @ResponsePayload
    public Source savePersona(@RequestPayload Source request) throws Exception {
        log.info("SOAP savePersona");

        Persona p = extractPersona(request);
        boolean ok = personaService.savePersona(p);

        Document doc = newDocument();
        Element resp = doc.createElementNS(NS, "savePersonaResponse");

        Element success = doc.createElementNS(NS, "success");
        success.setTextContent(String.valueOf(ok));
        resp.appendChild(success);

        Element mensaje = doc.createElementNS(NS, "mensaje");
        mensaje.setTextContent(ok ? "Guardado correctamente" : "Error al guardar");
        resp.appendChild(mensaje);

        doc.appendChild(resp);
        return new DOMSource(doc);
    }

    // -------------------------------------------------------
    // Helpers DOM
    // -------------------------------------------------------
    private Document newDocument() throws Exception {
        return javax.xml.parsers.DocumentBuilderFactory
                .newInstance().newDocumentBuilder().newDocument();
    }

    private Element buildPersonaElement(Document doc, Persona p) {
        Element pe = doc.createElementNS(NS, "persona");

        Element id = doc.createElementNS(NS, "id");
        id.setTextContent(String.valueOf(p.getId()));
        pe.appendChild(id);

        Element nom = doc.createElementNS(NS, "nombre");
        nom.setTextContent(p.getNombre());
        pe.appendChild(nom);

        Element ape = doc.createElementNS(NS, "apellido");
        ape.setTextContent(p.getApellido());
        pe.appendChild(ape);

        if (p.getEmail() != null) {
            Element email = doc.createElementNS(NS, "email");
            email.setTextContent(p.getEmail());
            pe.appendChild(email);
        }
        return pe;
    }

    private int extractInt(Source src, String tagName) throws Exception {
        DOMResult result = new DOMResult();
        javax.xml.transform.TransformerFactory.newInstance()
                .newTransformer().transform(src, result);
        Node root = result.getNode().getFirstChild();
        return Integer.parseInt(getText(root, tagName));
    }

    private Persona extractPersona(Source src) throws Exception {
        DOMResult result = new DOMResult();
        javax.xml.transform.TransformerFactory.newInstance()
                .newTransformer().transform(src, result);
        Node root = result.getNode().getFirstChild();   // savePersonaRequest
        Node pNode = ((Element) root).getElementsByTagNameNS(NS, "persona").item(0);

        Persona p = new Persona();
        p.setNombre(getText(pNode, "nombre"));
        p.setApellido(getText(pNode, "apellido"));
        p.setEmail(getText(pNode, "email"));
        return p;
    }

    private String getText(Node parent, String localName) {
        NodeList nl = ((Element) parent).getElementsByTagNameNS(NS, localName);
        if (nl.getLength() == 0) {
            nl = ((Element) parent).getElementsByTagName(localName); // fallback sin NS
        }
        return nl.getLength() > 0 ? nl.item(0).getTextContent().trim() : "";
    }
}
