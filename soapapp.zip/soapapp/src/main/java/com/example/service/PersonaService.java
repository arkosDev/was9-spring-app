package com.example.service;

import com.example.model.Persona;
import java.util.List;

public interface PersonaService {
    Persona getPersonaById(int id);
    List<Persona> getAllPersonas();
    boolean savePersona(Persona persona);
}
