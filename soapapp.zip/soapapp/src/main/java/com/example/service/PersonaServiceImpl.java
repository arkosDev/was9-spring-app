package com.example.service;

import com.example.dao.PersonaDao;
import com.example.model.Persona;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class PersonaServiceImpl implements PersonaService {

    private static final Logger log = LoggerFactory.getLogger(PersonaServiceImpl.class);

    private PersonaDao personaDao;

    // Inyectado desde app-context.xml
    public void setPersonaDao(PersonaDao personaDao) {
        this.personaDao = personaDao;
    }

    @Override
    public Persona getPersonaById(int id) {
        log.info("getPersonaById id={}", id);
        return personaDao.findById(id);
    }

    @Override
    public List<Persona> getAllPersonas() {
        log.info("getAllPersonas");
        return personaDao.findAll();
    }

    @Override
    public boolean savePersona(Persona persona) {
        log.info("savePersona nombre={}", persona.getNombre());
        int rows = personaDao.save(persona);
        return rows > 0;
    }
}
