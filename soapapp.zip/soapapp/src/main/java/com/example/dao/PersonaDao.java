package com.example.dao;

import com.example.model.Persona;
import java.util.List;

public interface PersonaDao {
    Persona findById(int id);
    List<Persona> findAll();
    int save(Persona persona);
}
