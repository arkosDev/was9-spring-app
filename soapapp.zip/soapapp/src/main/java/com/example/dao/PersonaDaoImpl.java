package com.example.dao;

import com.example.model.Persona;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class PersonaDaoImpl implements PersonaDao {

    private JdbcTemplate jdbcTemplate;

    // Inyectado desde app-context.xml
    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    // ---------------------------------------------------------
    // RowMapper reutilizable
    // ---------------------------------------------------------
    private static final RowMapper<Persona> ROW_MAPPER = new RowMapper<Persona>() {
        @Override
        public Persona mapRow(ResultSet rs, int rowNum) throws SQLException {
            return new Persona(
                rs.getInt("id"),
                rs.getString("nombre"),
                rs.getString("apellido"),
                rs.getString("email")
            );
        }
    };

    // ---------------------------------------------------------
    // findById
    // ---------------------------------------------------------
    @Override
    public Persona findById(int id) {
        String sql = "SELECT id, nombre, apellido, email FROM persona WHERE id = ?";
        List<Persona> lista = jdbcTemplate.query(sql, ROW_MAPPER, id);
        return lista.isEmpty() ? null : lista.get(0);
    }

    // ---------------------------------------------------------
    // findAll
    // ---------------------------------------------------------
    @Override
    public List<Persona> findAll() {
        String sql = "SELECT id, nombre, apellido, email FROM persona ORDER BY id";
        return jdbcTemplate.query(sql, ROW_MAPPER);
    }

    // ---------------------------------------------------------
    // save (INSERT)
    // ---------------------------------------------------------
    @Override
    public int save(Persona persona) {
        String sql = "INSERT INTO persona (nombre, apellido, email) VALUES (?, ?, ?)";
        return jdbcTemplate.update(sql,
                persona.getNombre(),
                persona.getApellido(),
                persona.getEmail());
    }
}
