# encoding-scanner

Proyecto Spring Boot (JDK 17, Maven, **sin parent**) que recorre un
directorio y sus subdirectorios, filtra archivos `.java`, `.xml` y
`.properties`, y para cada uno detecta:

- El encoding mas probable (`ASCII`, `UTF-8`, `UTF-8 con BOM`, `UTF-16`,
  o `ISO-8859-1 / Windows-1252` cuando el archivo no es UTF-8 valido).
- Todos los caracteres no-ASCII que contiene, con linea, columna y
  codepoint (util para encontrar tildes, enies, comillas tipograficas
  o basura de un mal re-encode).

El `pom.xml` no hereda de `spring-boot-starter-parent`: las versiones se
manejan importando `spring-boot-dependencies` como BOM en
`dependencyManagement`, y el `maven-compiler-plugin` / `spring-boot-maven-plugin`
llevan version explicita.

No usa ninguna libreria externa de chardet: la deteccion se hace con el
propio `CharsetDecoder` de la JDK en modo estricto (intenta decodificar
como UTF-8; si falla, cae a ISO-8859-1, que nunca falla porque mapea
1 byte = 1 caracter).

## Build

```bash
mvn clean package
```

## Uso

```bash
java -jar target/encoding-scanner.jar <directorio> [reporte.csv]
```

Ejemplos:

```bash
# Escanea el directorio actual, genera encoding-report.csv ahi mismo
java -jar target/encoding-scanner.jar .

# Escanea un proyecto especifico y guarda el reporte en otro lado
java -jar target/encoding-scanner.jar C:\proyectos\mi-app C:\temp\reporte.csv
```

Salida en consola: resumen por archivo (OK / OJO) + totales por encoding
detectado. El CSV trae el detalle completo, una fila por cada caracter
sospechoso encontrado.

## Configuracion

En `src/main/resources/application.properties`:

```properties
# Extensiones a escanear (sin punto, separadas por coma)
scanner.extensions=java,xml,properties

# Carpetas que se ignoran durante el recorrido
scanner.exclude-dirs=target,.git,node_modules,build,.idea,.settings
```

Tambien se pueden sobreescribir por linea de comandos, ej:

```bash
java -jar target/encoding-scanner.jar . reporte.csv --scanner.extensions=java,xml,properties,sql
```
