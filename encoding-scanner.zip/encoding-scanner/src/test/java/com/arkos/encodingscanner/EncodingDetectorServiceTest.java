package com.arkos.encodingscanner;

import com.arkos.encodingscanner.model.FileScanResult;
import com.arkos.encodingscanner.model.MojibakeMatch;
import com.arkos.encodingscanner.service.EncodingDetectorService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class EncodingDetectorServiceTest {

    private final EncodingDetectorService service = new EncodingDetectorService();

    @Test
    void archivoAsciiPuroNoDeberiaTenerAlertas(@TempDir Path tempDir) throws Exception {
        Path file = tempDir.resolve("Ascii.java");
        Files.writeString(file, "public class Ascii { }", StandardCharsets.US_ASCII);

        FileScanResult result = service.scan(file);

        assertTrue(result.mojibakeMatches().isEmpty());
        assertFalse(result.hasIssues());
    }

    @Test
    void archivoUtf8ConAcentosCorrectosNoDeberiaTenerAlertas(@TempDir Path tempDir) throws Exception {
        // "Configuración, niño" ya esta bien codificado en UTF-8: NO debe marcarse
        Path file = tempDir.resolve("Utf8.properties");
        Files.writeString(file, "mensaje=Configuraci\u00f3n incorrecta, ni\u00f1o", StandardCharsets.UTF_8);

        FileScanResult result = service.scan(file);

        assertEquals("UTF-8", result.detectedEncoding());
        assertTrue(result.validUtf8());
        assertTrue(result.mojibakeMatches().isEmpty());
        assertFalse(result.hasIssues());
    }

    @Test
    void archivoConMojibakeDeberiaDetectarloYReconstruirlo(@TempDir Path tempDir) throws Exception {
        // Simulamos el caso real: "Configuración" se guardo en UTF-8, pero
        // luego alguien tomo esos bytes y los re-guardo como si fueran
        // ISO-8859-1 -> "ó" (bytes UTF-8 0xC3 0xB3) se vuelve "Ã³" (2 chars)
        Path file = tempDir.resolve("Mojibake.xml");
        byte[] utf8OriginalBytes = "Configuraci\u00f3n".getBytes(StandardCharsets.UTF_8);
        String mojibakeText = new String(utf8OriginalBytes, StandardCharsets.ISO_8859_1);
        Files.write(file, mojibakeText.getBytes(StandardCharsets.UTF_8));

        FileScanResult result = service.scan(file);

        assertTrue(result.validUtf8());
        assertFalse(result.mojibakeMatches().isEmpty());
        MojibakeMatch match = result.mojibakeMatches().get(0);
        assertEquals(MojibakeMatch.Kind.DOBLE_CODIFICACION, match.kind());
        assertEquals("\u00f3", match.reconstructedChar());
    }

    @Test
    void archivoIso88591CrudoDeberiaDetectarseComoNoUtf8(@TempDir Path tempDir) throws Exception {
        Path file = tempDir.resolve("Iso.xml");
        // "Configuración" codificado directamente en ISO-8859-1 (1 byte por char)
        Files.write(file, "Configuraci\u00f3n".getBytes(StandardCharsets.ISO_8859_1));

        FileScanResult result = service.scan(file);

        assertFalse(result.validUtf8());
        assertTrue(result.detectedEncoding().contains("ISO-8859-1"));
        assertFalse(result.mojibakeMatches().isEmpty());
        assertEquals(MojibakeMatch.Kind.BYTE_NO_UTF8, result.mojibakeMatches().get(0).kind());
    }
}
