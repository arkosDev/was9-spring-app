package com.arkos.encodingscanner;

import com.arkos.encodingscanner.model.FileScanResult;
import com.arkos.encodingscanner.service.EncodingDetectorService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class EncodingDetectorServiceTest {

    private final EncodingDetectorService service = new EncodingDetectorService();

    @Test
    void archivoAsciiPuroNoDeberiaTenerAlertas(@TempDir Path tempDir) throws Exception {
        Path file = tempDir.resolve("Ascii.java");
        Files.writeString(file, "public class Ascii { }", StandardCharsets.US_ASCII);

        FileScanResult result = service.scan(file);

        assertTrue(result.detectedEncoding().startsWith("ASCII"));
        assertTrue(result.suspiciousChars().isEmpty());
        assertFalse(result.hasIssues());
    }

    @Test
    void archivoUtf8ValidoConAcentosDeberiaListarLosCaracteres(@TempDir Path tempDir) throws Exception {
        Path file = tempDir.resolve("Utf8.properties");
        Files.writeString(file, "mensaje=Configuraci\u00f3n incorrecta, ni\u00f1o", StandardCharsets.UTF_8);

        FileScanResult result = service.scan(file);

        assertEquals("UTF-8", result.detectedEncoding());
        assertTrue(result.validUtf8());
        assertEquals(2, result.suspiciousChars().size());
    }

    @Test
    void archivoIso88591DeberiaDetectarseComoNoUtf8(@TempDir Path tempDir) throws Exception {
        Path file = tempDir.resolve("Iso.xml");
        // "Configuración" codificado directamente en ISO-8859-1
        Files.write(file, "Configuraci\u00f3n".getBytes(StandardCharsets.ISO_8859_1));

        FileScanResult result = service.scan(file);

        assertFalse(result.validUtf8());
        assertTrue(result.detectedEncoding().contains("ISO-8859-1"));
        assertEquals(1, result.suspiciousChars().size());
    }
}
