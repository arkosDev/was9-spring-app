package com.arkos.encodingscanner.runner;

import com.arkos.encodingscanner.model.FileScanResult;
import com.arkos.encodingscanner.report.ReportWriter;
import com.arkos.encodingscanner.service.DirectoryWalkerService;
import com.arkos.encodingscanner.service.EncodingDetectorService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/**
 * Punto de entrada de la logica de negocio.
 *
 * Uso:
 *   java -jar encoding-scanner.jar <directorio> [reporte.csv]
 *
 * Si no se pasa directorio, usa el directorio actual (".").
 * Si no se pasa nombre de CSV, genera "encoding-report.csv" en el directorio actual.
 */
@Component
public class ScanRunner implements CommandLineRunner {

    private final DirectoryWalkerService directoryWalkerService;
    private final EncodingDetectorService encodingDetectorService;
    private final ReportWriter reportWriter;

    public ScanRunner(DirectoryWalkerService directoryWalkerService,
                       EncodingDetectorService encodingDetectorService,
                       ReportWriter reportWriter) {
        this.directoryWalkerService = directoryWalkerService;
        this.encodingDetectorService = encodingDetectorService;
        this.reportWriter = reportWriter;
    }

    @Override
    public void run(String... args) throws Exception {
        Path rootDir = Paths.get(args.length > 0 ? args[0] : ".").toAbsolutePath().normalize();
        Path outputCsv = Paths.get(args.length > 1 ? args[1] : "encoding-report.csv").toAbsolutePath().normalize();

        if (!Files.isDirectory(rootDir)) {
            System.err.println("El directorio no existe o no es un directorio valido: " + rootDir);
            System.exit(1);
            return;
        }

        System.out.println("Escaneando: " + rootDir);

        List<Path> files = directoryWalkerService.collectFiles(rootDir);
        System.out.println("Archivos encontrados (.java/.xml/.properties): " + files.size());

        List<FileScanResult> results = new ArrayList<>();
        for (Path file : files) {
            results.add(encodingDetectorService.scan(file));
        }

        reportWriter.printConsoleSummary(results);
        reportWriter.writeCsvReport(results, outputCsv);

        System.out.println();
        System.out.println("Reporte CSV escrito en: " + outputCsv);
    }
}
