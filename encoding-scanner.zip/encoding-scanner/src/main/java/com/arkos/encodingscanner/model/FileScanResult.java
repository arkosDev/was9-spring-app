package com.arkos.encodingscanner.model;

import java.nio.file.Path;
import java.util.List;

/**
 * Resultado del analisis de un archivo: encoding detectado, si el archivo
 * es UTF-8 valido, y el listado de fragmentos de mojibake detectados
 * (texto ISO-8859-1 reinterpretado como UTF-8 que se ve ilegible).
 */
public record FileScanResult(
        Path file,
        String detectedEncoding,
        boolean hasBom,
        boolean validUtf8,
        List<MojibakeMatch> mojibakeMatches,
        String error
) {

    public boolean hasIssues() {
        return error != null || !mojibakeMatches.isEmpty() || !validUtf8;
    }

    public int issueCount() {
        return mojibakeMatches.size();
    }
}
