package com.arkos.encodingscanner.model;

import java.nio.file.Path;
import java.util.List;

/**
 * Resultado del analisis de un archivo: encoding detectado, si tenia BOM,
 * y el listado de caracteres no-ASCII / sospechosos que se encontraron.
 */
public record FileScanResult(
        Path file,
        String detectedEncoding,
        boolean hasBom,
        boolean validUtf8,
        List<SuspiciousChar> suspiciousChars,
        String error
) {

    public boolean hasIssues() {
        return error != null || !suspiciousChars.isEmpty() || !validUtf8;
    }

    public int issueCount() {
        return suspiciousChars.size();
    }
}
