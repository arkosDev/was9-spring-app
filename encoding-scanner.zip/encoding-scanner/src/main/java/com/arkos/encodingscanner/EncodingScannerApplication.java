package com.arkos.encodingscanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EncodingScannerApplication {

    public static void main(String[] args) {
        // Como es una app de consola, apagamos el banner para que la salida quede limpia
        SpringApplication app = new SpringApplication(EncodingScannerApplication.class);
        app.setLogStartupInfo(false);
        app.run(args);
    }
}
