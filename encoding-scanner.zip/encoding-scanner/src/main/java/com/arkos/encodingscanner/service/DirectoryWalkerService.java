package com.arkos.encodingscanner.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Recorre recursivamente un directorio y devuelve los archivos que
 * coinciden con las extensiones configuradas, ignorando carpetas
 * tipicas que no queremos escanear (target, .git, node_modules, etc.)
 */
@Service
public class DirectoryWalkerService {

    @Value("${scanner.extensions:java,xml,properties}")
    private String extensionsProperty;

    @Value("${scanner.exclude-dirs:target,.git,node_modules,build,.idea,.settings}")
    private String excludeDirsProperty;

    public List<Path> collectFiles(Path rootDir) throws IOException {
        Set<String> extensions = Arrays.stream(extensionsProperty.split(","))
                .map(String::trim)
                .map(String::toLowerCase)
                .collect(Collectors.toSet());

        Set<String> excludedDirs = Arrays.stream(excludeDirsProperty.split(","))
                .map(String::trim)
                .collect(Collectors.toSet());

        try (Stream<Path> walk = Files.walk(rootDir)) {
            return walk
                    .filter(Files::isRegularFile)
                    .filter(p -> !isInsideExcludedDir(rootDir, p, excludedDirs))
                    .filter(p -> extensions.contains(getExtension(p)))
                    .sorted()
                    .collect(Collectors.toList());
        }
    }

    private boolean isInsideExcludedDir(Path root, Path file, Set<String> excludedDirs) {
        Path relative = root.relativize(file);
        for (Path part : relative) {
            if (excludedDirs.contains(part.toString())) {
                return true;
            }
        }
        return false;
    }

    private String getExtension(Path path) {
        String name = path.getFileName().toString();
        int dot = name.lastIndexOf('.');
        if (dot < 0 || dot == name.length() - 1) {
            return "";
        }
        return name.substring(dot + 1).toLowerCase();
    }
}
