package com.arkos.encodingscanner.model;

/**
 * Representa un fragmento de texto problematico por encoding.
 *
 * Hay dos "kind" posibles:
 *  - DOBLE_CODIFICACION: el archivo SI es UTF-8 valido, pero un caracter
 *    ISO-8859-1/Windows-1252 (tilde, enie, etc.) quedo re-codificado como
 *    si sus bytes fueran texto, produciendo una secuencia rara de 2-3
 *    caracteres (ej. "Ã±" en vez de "ñ"). Se reconstruye el caracter
 *    original para mostrarlo.
 *  - BYTE_NO_UTF8: el archivo completo NO es UTF-8 valido (probablemente
 *    esta guardado en ISO-8859-1/Windows-1252 crudo). Se reporta cada
 *    byte no-ASCII tal cual, sin reconstruccion posible.
 */
public record MojibakeMatch(
        Kind kind,
        int line,
        int column,
        String garbledText,
        String reconstructedChar
) {

    public enum Kind {
        DOBLE_CODIFICACION,
        BYTE_NO_UTF8
    }

    public String reconstructedHex() {
        if (reconstructedChar == null || reconstructedChar.isEmpty()) {
            return "?";
        }
        return String.format("U+%04X", reconstructedChar.codePointAt(0));
    }
}
