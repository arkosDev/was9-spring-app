package com.arkos.encodingscanner.report;

import com.arkos.encodingscanner.model.FileScanResult;
import com.arkos.encodingscanner.model.MojibakeMatch;
import org.springframework.stereotype.Component;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

@Component
public class ReportWriter {

    private static final int MAX_MATCHES_TO_PRINT_PER_FILE = 5;

    /**
     * Imprime en consola solo los archivos con problemas reales de encoding
     * (mojibake o bytes fuera de UTF-8). Los archivos limpios se cuentan
     * en el total pero no ensucian la salida linea por linea.
     */
    public void printConsoleSummary(List<FileScanResult> results) {
        System.out.println();
        System.out.println("========================================================================");
        System.out.println(" REPORTE DE ENCODING (mojibake / caracteres ISO mal codificados)");
        System.out.println("========================================================================");

        Map<String, Integer> countByEncoding = new TreeMap<>();
        long conProblemas = 0;

        for (FileScanResult result : results) {
            countByEncoding.merge(result.detectedEncoding(), 1, Integer::sum);

            if (result.error() != null) {
                System.out.printf("[ERROR] %s -> %s%n", result.file(), result.error());
                continue;
            }

            if (!result.hasIssues()) {
                continue;
            }

            conProblemas++;
            System.out.printf("[OJO] %s -> %s (%d problema(s))%n",
                    result.file(), result.detectedEncoding(), result.issueCount());

            List<MojibakeMatch> preview = result.mojibakeMatches().stream()
                    .limit(MAX_MATCHES_TO_PRINT_PER_FILE)
                    .toList();
            for (MojibakeMatch m : preview) {
                if (m.kind() == MojibakeMatch.Kind.DOBLE_CODIFICACION) {
                    System.out.printf("        linea %d, col %d: '%s' -> deberia ser '%s' (%s)%n",
                            m.line(), m.column(), m.garbledText(), m.reconstructedChar(), m.reconstructedHex());
                } else {
                    System.out.printf("        linea %d, col %d: byte no-UTF8 '%s'%n",
                            m.line(), m.column(), m.garbledText());
                }
            }
            if (result.issueCount() > MAX_MATCHES_TO_PRINT_PER_FILE) {
                System.out.printf("        ... y %d mas (ver CSV para el detalle completo)%n",
                        result.issueCount() - MAX_MATCHES_TO_PRINT_PER_FILE);
            }
        }

        System.out.println("------------------------------------------------------------------------");
        System.out.println(" Totales por encoding detectado:");
        countByEncoding.forEach((enc, count) -> System.out.printf("   %-55s %d archivo(s)%n", enc, count));

        System.out.println("------------------------------------------------------------------------");
        System.out.printf(" Total de archivos escaneados : %d%n", results.size());
        System.out.printf(" Total de archivos con problemas de encoding: %d%n", conProblemas);
        System.out.println("========================================================================");
    }

    /**
     * CSV con el detalle completo de cada problema encontrado. Los archivos
     * sin problemas NO generan fila (para no inflar el reporte con ruido).
     */
    public void writeCsvReport(List<FileScanResult> results, Path outputCsv) throws IOException {
        try (BufferedWriter writer = Files.newBufferedWriter(outputCsv, StandardCharsets.UTF_8)) {
            writer.write("archivo,encoding_detectado,tipo_problema,linea,columna,texto_encontrado,deberia_ser,error");
            writer.newLine();

            for (FileScanResult result : results) {
                if (result.error() != null) {
                    writer.write(csvLine(result.file().toString(), result.detectedEncoding(),
                            "", "", "", "", "", result.error()));
                    writer.newLine();
                    continue;
                }

                for (MojibakeMatch m : result.mojibakeMatches()) {
                    writer.write(csvLine(result.file().toString(), result.detectedEncoding(),
                            m.kind().name(),
                            String.valueOf(m.line()),
                            String.valueOf(m.column()),
                            m.garbledText(),
                            m.kind() == MojibakeMatch.Kind.DOBLE_CODIFICACION ? m.reconstructedChar() : "",
                            ""));
                    writer.newLine();
                }
            }
        }
    }

    private String csvLine(String... fields) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < fields.length; i++) {
            if (i > 0) {
                sb.append(',');
            }
            sb.append(escapeCsv(fields[i]));
        }
        return sb.toString();
    }

    private String escapeCsv(String value) {
        if (value == null) {
            return "";
        }
        if (value.contains(",") || value.contains("\"") || value.contains("\n")) {
            return "\"" + value.replace("\"", "\"\"") + "\"";
        }
        return value;
    }
}
