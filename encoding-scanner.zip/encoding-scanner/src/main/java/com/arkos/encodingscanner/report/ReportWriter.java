package com.arkos.encodingscanner.report;

import com.arkos.encodingscanner.model.FileScanResult;
import com.arkos.encodingscanner.model.SuspiciousChar;
import org.springframework.stereotype.Component;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

@Component
public class ReportWriter {

    private static final int MAX_CHARS_TO_PRINT_PER_FILE = 5;

    /**
     * Imprime en consola un resumen legible: encoding detectado por archivo
     * y, si tiene caracteres sospechosos, un preview de los primeros.
     */
    public void printConsoleSummary(List<FileScanResult> results) {
        System.out.println();
        System.out.println("========================================================================");
        System.out.println(" REPORTE DE ENCODING");
        System.out.println("========================================================================");

        Map<String, Integer> countByEncoding = new TreeMap<>();

        for (FileScanResult result : results) {
            countByEncoding.merge(result.detectedEncoding(), 1, Integer::sum);

            if (result.error() != null) {
                System.out.printf("[ERROR]   %s -> %s%n", result.file(), result.error());
                continue;
            }

            String flag = result.validUtf8() ? " " : "!";
            System.out.printf("[%s]%s %s -> %s%s%n",
                    result.issueCount() > 0 ? "OJO" : "OK ",
                    flag,
                    result.file(),
                    result.detectedEncoding(),
                    result.issueCount() > 0 ? " (" + result.issueCount() + " caracteres no-ASCII)" : "");

            if (result.issueCount() > 0) {
                List<SuspiciousChar> preview = result.suspiciousChars().stream()
                        .limit(MAX_CHARS_TO_PRINT_PER_FILE)
                        .toList();
                for (SuspiciousChar sc : preview) {
                    System.out.printf("          linea %d, col %d: '%s' (%s)%n",
                            sc.line(), sc.column(), sc.displayChar(), sc.hexCodePoint());
                }
                if (result.issueCount() > MAX_CHARS_TO_PRINT_PER_FILE) {
                    System.out.printf("          ... y %d mas (ver CSV para el detalle completo)%n",
                            result.issueCount() - MAX_CHARS_TO_PRINT_PER_FILE);
                }
            }
        }

        System.out.println("------------------------------------------------------------------------");
        System.out.println(" Totales por encoding detectado:");
        countByEncoding.forEach((enc, count) -> System.out.printf("   %-55s %d archivo(s)%n", enc, count));

        long conIssues = results.stream().filter(FileScanResult::hasIssues).count();
        System.out.println("------------------------------------------------------------------------");
        System.out.printf(" Total de archivos escaneados : %d%n", results.size());
        System.out.printf(" Total de archivos con alertas: %d%n", conIssues);
        System.out.println("========================================================================");
    }

    /**
     * Escribe un CSV con el detalle completo: una fila por cada caracter
     * sospechoso encontrado (o una fila resumen si el archivo no tuvo ninguno).
     */
    public void writeCsvReport(List<FileScanResult> results, Path outputCsv) throws IOException {
        try (BufferedWriter writer = Files.newBufferedWriter(outputCsv, StandardCharsets.UTF_8)) {
            writer.write("archivo,encoding_detectado,utf8_valido,linea,columna,codepoint,caracter,error");
            writer.newLine();

            for (FileScanResult result : results) {
                if (result.error() != null) {
                    writer.write(csvLine(result.file().toString(), result.detectedEncoding(),
                            "", "", "", "", "", result.error()));
                    writer.newLine();
                    continue;
                }

                if (result.suspiciousChars().isEmpty()) {
                    writer.write(csvLine(result.file().toString(), result.detectedEncoding(),
                            String.valueOf(result.validUtf8()), "", "", "", "", ""));
                    writer.newLine();
                } else {
                    for (SuspiciousChar sc : result.suspiciousChars()) {
                        writer.write(csvLine(result.file().toString(), result.detectedEncoding(),
                                String.valueOf(result.validUtf8()),
                                String.valueOf(sc.line()),
                                String.valueOf(sc.column()),
                                sc.hexCodePoint(),
                                sc.displayChar(),
                                ""));
                        writer.newLine();
                    }
                }
            }
        }
    }

    private String csvLine(String... fields) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < fields.length; i++) {
            if (i > 0) {
                sb.append(',');
            }
            sb.append(escapeCsv(fields[i]));
        }
        return sb.toString();
    }

    private String escapeCsv(String value) {
        if (value == null) {
            return "";
        }
        if (value.contains(",") || value.contains("\"") || value.contains("\n")) {
            return "\"" + value.replace("\"", "\"\"") + "\"";
        }
        return value;
    }
}
