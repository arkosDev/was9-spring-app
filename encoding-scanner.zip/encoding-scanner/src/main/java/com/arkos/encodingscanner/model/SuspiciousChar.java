package com.arkos.encodingscanner.model;

/**
 * Representa un caracter no-ASCII (posible caracter ISO-8859-1 / Windows-1252
 * mal codificado, tilde, enie, comilla tipografica, etc.) detectado dentro
 * de un archivo, con su ubicacion exacta.
 */
public record SuspiciousChar(
        int line,
        int column,
        int codePoint,
        String displayChar
) {

    public String hexCodePoint() {
        return String.format("U+%04X", codePoint);
    }

    /**
     * Representacion imprimible del caracter. Si es un caracter de control
     * (no imprimible) se muestra su nombre en vez del glifo, para no
     * ensuciar la consola.
     */
    public static String toDisplay(int codePoint) {
        if (Character.isISOControl(codePoint)) {
            return "[CTRL-" + codePoint + "]";
        }
        return new String(Character.toChars(codePoint));
    }
}
