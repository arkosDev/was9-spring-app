package com.arkos.encodingscanner.service;

import com.arkos.encodingscanner.model.FileScanResult;
import com.arkos.encodingscanner.model.SuspiciousChar;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.MalformedInputException;
import java.nio.charset.StandardCharsets;
import java.nio.charset.UnmappableCharacterException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * Detecta, sin depender de librerias externas de chardet, el encoding mas
 * probable de un archivo de texto y localiza los caracteres no-ASCII que
 * contiene (candidatos a estar mal codificados si el archivo se supone
 * UTF-8 pero en realidad viene en ISO-8859-1 / Windows-1252, tipico de
 * exports de Windows o de editores viejos).
 *
 * Estrategia:
 *  1. Revisa BOM (UTF-8 / UTF-16 LE / UTF-16 BE).
 *  2. Si no hay BOM, intenta decodificar en modo estricto como UTF-8.
 *     Si falla (MalformedInputException / UnmappableCharacterException),
 *     el archivo NO es UTF-8 valido -> se decodifica como ISO-8859-1
 *     (que nunca falla, ya que mapea 1 byte = 1 caracter) para poder
 *     seguir listando los caracteres problematicos.
 *  3. Recorre el texto decodificado y reporta cualquier caracter fuera
 *     del rango ASCII imprimible (0x00-0x7F), con su linea y columna.
 */
@Service
public class EncodingDetectorService {

    private static final byte[] UTF8_BOM = {(byte) 0xEF, (byte) 0xBB, (byte) 0xBF};
    private static final byte[] UTF16_LE_BOM = {(byte) 0xFF, (byte) 0xFE};
    private static final byte[] UTF16_BE_BOM = {(byte) 0xFE, (byte) 0xFF};

    public FileScanResult scan(Path file) {
        byte[] bytes;
        try {
            bytes = Files.readAllBytes(file);
        } catch (IOException e) {
            return new FileScanResult(file, "DESCONOCIDO", false, false, List.of(),
                    "No se pudo leer el archivo: " + e.getMessage());
        }

        if (startsWith(bytes, UTF8_BOM)) {
            return analyze(file, bytes, 3, StandardCharsets.UTF_8, "UTF-8 (con BOM)", true, true);
        }
        if (startsWith(bytes, UTF16_LE_BOM)) {
            return new FileScanResult(file, "UTF-16 LE (con BOM)", true, true, List.of(), null);
        }
        if (startsWith(bytes, UTF16_BE_BOM)) {
            return new FileScanResult(file, "UTF-16 BE (con BOM)", true, true, List.of(), null);
        }

        // Sin BOM: intentamos UTF-8 estricto primero
        CharsetDecoder strictUtf8 = StandardCharsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT);
        try {
            CharBuffer decoded = strictUtf8.decode(ByteBuffer.wrap(bytes));
            boolean pureAscii = isPureAscii(bytes);
            String encodingLabel = pureAscii ? "ASCII (subset de UTF-8)" : "UTF-8";
            return analyzeChars(file, decoded.toString(), encodingLabel, false, true, null);
        } catch (MalformedInputException | UnmappableCharacterException e) {
            // No es UTF-8 valido. Lo mas probable en entornos legacy es
            // ISO-8859-1 (Latin-1) o su primo Windows-1252. Decodificamos
            // como ISO-8859-1 porque nunca lanza error (1 byte = 1 char)
            // y asi podemos reportar la ubicacion exacta de los bytes raros.
            String decoded = new String(bytes, StandardCharsets.ISO_8859_1);
            return analyzeChars(file, decoded, "ISO-8859-1 / Windows-1252 (probable; no es UTF-8 valido)",
                    false, false, null);
        } catch (Exception e) {
            return new FileScanResult(file, "DESCONOCIDO", false, false, List.of(),
                    "Error al decodificar: " + e.getMessage());
        }
    }

    private FileScanResult analyze(Path file, byte[] bytes, int offset, Charset charset,
                                    String label, boolean hasBom, boolean validUtf8) {
        String text = new String(bytes, offset, bytes.length - offset, charset);
        return analyzeChars(file, text, label, hasBom, validUtf8, null);
    }

    private FileScanResult analyzeChars(Path file, String text, String encodingLabel,
                                         boolean hasBom, boolean validUtf8, String error) {
        List<SuspiciousChar> suspicious = new ArrayList<>();
        int line = 1;
        int column = 0;
        int i = 0;
        while (i < text.length()) {
            int codePoint = text.codePointAt(i);
            int charCount = Character.charCount(codePoint);
            if (codePoint == '\n') {
                line++;
                column = 0;
            } else {
                column++;
                if (codePoint > 0x7F) {
                    suspicious.add(new SuspiciousChar(line, column, codePoint,
                            SuspiciousChar.toDisplay(codePoint)));
                }
            }
            i += charCount;
        }
        return new FileScanResult(file, encodingLabel, hasBom, validUtf8, suspicious, error);
    }

    private boolean isPureAscii(byte[] bytes) {
        for (byte b : bytes) {
            if ((b & 0x80) != 0) {
                return false;
            }
        }
        return true;
    }

    private boolean startsWith(byte[] bytes, byte[] prefix) {
        if (bytes.length < prefix.length) {
            return false;
        }
        for (int i = 0; i < prefix.length; i++) {
            if (bytes[i] != prefix[i]) {
                return false;
            }
        }
        return true;
    }
}
