package com.arkos.encodingscanner.service;

import com.arkos.encodingscanner.model.FileScanResult;
import com.arkos.encodingscanner.model.MojibakeMatch;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.MalformedInputException;
import java.nio.charset.StandardCharsets;
import java.nio.charset.UnmappableCharacterException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * Detecta problemas reales de encoding, sin depender de librerias externas
 * de chardet:
 *
 *  CASO 1 - Archivo NO es UTF-8 valido (falla el decode estricto):
 *      El archivo esta guardado en ISO-8859-1 / Windows-1252 crudo.
 *      Se decodifica como ISO-8859-1 (nunca falla, 1 byte = 1 char) y se
 *      reporta cada byte no-ASCII encontrado.
 *
 *  CASO 2 - Archivo SI es UTF-8 valido, pero tiene "mojibake" (doble
 *      codificacion): en algun momento un editor/proceso tomo bytes
 *      ISO-8859-1 (ej. los 2 bytes UTF-8 de una "ñ": 0xC3 0xB1) y los
 *      volvio a interpretar como si CADA byte fuera un caracter Latin-1,
 *      produciendo texto tipo "Ã±" en vez de "ñ". Esto se detecta
 *      reconstruyendo: se toman ventanas de 2-3 caracteres consecutivos,
 *      se convierten a bytes crudos (1 char = 1 byte, como ISO-8859-1) y
 *      se intenta decodificar ese byte[] como UTF-8 estricto. Si funciona
 *      y da como resultado UN solo caracter valido, es mojibake.
 *
 * Los acentos/enies que YA estan bien codificados en UTF-8 (un solo
 * caracter, ej. "ñ", "é") NO se reportan como problema.
 */
@Service
public class EncodingDetectorService {

    private static final byte[] UTF8_BOM = {(byte) 0xEF, (byte) 0xBB, (byte) 0xBF};
    private static final byte[] UTF16_LE_BOM = {(byte) 0xFF, (byte) 0xFE};
    private static final byte[] UTF16_BE_BOM = {(byte) 0xFE, (byte) 0xFF};

    // Se prueban ventanas de 3 bytes primero (comillas tipograficas, guiones
    // largos: â€™, â€œ...) y luego de 2 bytes (tildes, enies: Ã±, Ã©...)
    private static final int[] WINDOW_LENGTHS = {3, 2};

    public FileScanResult scan(Path file) {
        byte[] bytes;
        try {
            bytes = Files.readAllBytes(file);
        } catch (IOException e) {
            return new FileScanResult(file, "DESCONOCIDO", false, false, List.of(),
                    "No se pudo leer el archivo: " + e.getMessage());
        }

        if (startsWith(bytes, UTF8_BOM)) {
            String text = new String(bytes, 3, bytes.length - 3, StandardCharsets.UTF_8);
            return analyzeValidUtf8(file, text, "UTF-8 (con BOM)", true);
        }
        if (startsWith(bytes, UTF16_LE_BOM)) {
            return new FileScanResult(file, "UTF-16 LE (con BOM)", true, true, List.of(), null);
        }
        if (startsWith(bytes, UTF16_BE_BOM)) {
            return new FileScanResult(file, "UTF-16 BE (con BOM)", true, true, List.of(), null);
        }

        CharsetDecoder strictUtf8 = StandardCharsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT);
        try {
            CharBuffer decoded = strictUtf8.decode(ByteBuffer.wrap(bytes));
            String encodingLabel = isPureAscii(bytes) ? "ASCII (subset de UTF-8)" : "UTF-8";
            return analyzeValidUtf8(file, decoded.toString(), encodingLabel, false);
        } catch (MalformedInputException | UnmappableCharacterException e) {
            // El archivo NO es UTF-8 valido: es ISO-8859-1 / Windows-1252 crudo
            String decoded = new String(bytes, StandardCharsets.ISO_8859_1);
            List<MojibakeMatch> matches = findRawNonAsciiBytes(decoded);
            return new FileScanResult(file, "ISO-8859-1 / Windows-1252 (no es UTF-8 valido)",
                    false, false, matches, null);
        } catch (Exception e) {
            return new FileScanResult(file, "DESCONOCIDO", false, false, List.of(),
                    "Error al decodificar: " + e.getMessage());
        }
    }

    /**
     * Archivo confirmado como UTF-8 valido: solo buscamos mojibake
     * (doble codificacion), no marcamos acentos normales.
     */
    private FileScanResult analyzeValidUtf8(Path file, String text, String encodingLabel, boolean hasBom) {
        List<MojibakeMatch> matches = findMojibake(text);
        return new FileScanResult(file, encodingLabel, hasBom, true, matches, null);
    }

    /**
     * Recorre el texto buscando ventanas de caracteres que, reinterpretados
     * como bytes crudos, formen un caracter UTF-8 valido -> eso es mojibake.
     */
    private List<MojibakeMatch> findMojibake(String text) {
        List<MojibakeMatch> matches = new ArrayList<>();
        int line = 1;
        int lineStartIndex = 0;

        int i = 0;
        while (i < text.length()) {
            char c = text.charAt(i);
            if (c == '\n') {
                line++;
                lineStartIndex = i + 1;
                i++;
                continue;
            }

            boolean matched = false;
            for (int len : WINDOW_LENGTHS) {
                if (i + len > text.length()) {
                    continue;
                }
                String window = text.substring(i, i + len);
                if (!allInHighByteRange(window)) {
                    continue;
                }
                String reconstructed = tryReconstructUtf8Char(window);
                if (reconstructed != null) {
                    int column = i - lineStartIndex + 1;
                    matches.add(new MojibakeMatch(MojibakeMatch.Kind.DOBLE_CODIFICACION,
                            line, column, window, reconstructed));
                    i += len;
                    matched = true;
                    break;
                }
            }
            if (!matched) {
                i++;
            }
        }
        return matches;
    }

    /**
     * Toma una ventana de 2-3 caracteres, cada uno tratado como 1 byte
     * (0x80-0xFF), y trata de decodificarlos como UTF-8 estricto. Si el
     * resultado es exactamente 1 caracter imprimible, es una reconstruccion
     * valida -> mojibake confirmado.
     */
    private String tryReconstructUtf8Char(String window) {
        byte[] bytes = new byte[window.length()];
        for (int j = 0; j < window.length(); j++) {
            bytes[j] = (byte) window.charAt(j);
        }
        CharsetDecoder decoder = StandardCharsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT);
        try {
            CharBuffer decoded = decoder.decode(ByteBuffer.wrap(bytes));
            String result = decoded.toString();
            if (result.codePointCount(0, result.length()) == 1) {
                int cp = result.codePointAt(0);
                if (!Character.isISOControl(cp) && cp > 0x7F) {
                    return result;
                }
            }
            return null;
        } catch (Exception e) {
            return null;
        }
    }

    private boolean allInHighByteRange(String s) {
        for (int j = 0; j < s.length(); j++) {
            char c = s.charAt(j);
            if (c < 0x80 || c > 0xFF) {
                return false;
            }
        }
        return true;
    }

    /**
     * Para archivos que NO son UTF-8 valido: se reporta cada caracter
     * no-ASCII tal cual (ya decodificado como ISO-8859-1), porque el
     * archivo entero necesita re-encode, no hay "reconstruccion" que hacer.
     */
    private List<MojibakeMatch> findRawNonAsciiBytes(String text) {
        List<MojibakeMatch> matches = new ArrayList<>();
        int line = 1;
        int lineStartIndex = 0;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == '\n') {
                line++;
                lineStartIndex = i + 1;
                continue;
            }
            if (c > 0x7F) {
                int column = i - lineStartIndex + 1;
                String display = Character.isISOControl(c) ? "[CTRL-" + (int) c + "]" : String.valueOf(c);
                matches.add(new MojibakeMatch(MojibakeMatch.Kind.BYTE_NO_UTF8, line, column, display, display));
            }
        }
        return matches;
    }

    private boolean isPureAscii(byte[] bytes) {
        for (byte b : bytes) {
            if ((b & 0x80) != 0) {
                return false;
            }
        }
        return true;
    }

    private boolean startsWith(byte[] bytes, byte[] prefix) {
        if (bytes.length < prefix.length) {
            return false;
        }
        for (int i = 0; i < prefix.length; i++) {
            if (bytes[i] != prefix[i]) {
                return false;
            }
        }
        return true;
    }
}
