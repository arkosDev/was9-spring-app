# struts-wso2-app

Aplicación J2EE con **Struts 1.1 + JSP** que implementa autenticación y logout
via **WSO2 IS 7.x** usando el flujo **OIDC Authorization Code**.

Desplegable en **WAS 9** con **JDK 8**.

---

## Estructura del proyecto

```
struts-wso2-app/
├── pom.xml
└── src/main/
    ├── java/com/example/
    │   ├── action/
    │   │   ├── LoginAction.java          ← Inicia flujo OIDC
    │   │   ├── OIDCCallbackAction.java   ← Recibe code de WSO2 IS
    │   │   ├── HomeAction.java           ← Página protegida
    │   │   └── LogoutAction.java         ← Cierra sesión local + WSO2 IS
    │   ├── filter/
    │   │   └── AuthFilter.java           ← Protege /pages/secure/*
    │   ├── model/
    │   │   └── OIDCUser.java             ← Datos del usuario autenticado
    │   └── util/
    │       ├── OIDCConfig.java           ← ★ CONFIGURA AQUÍ tus parámetros
    │       └── OIDCService.java          ← Lógica OIDC (token exchange, userinfo, logout)
    ├── resources/
    │   └── com/example/ApplicationResources.properties
    └── webapp/
        ├── css/style.css
        ├── login.jsp                     ← Página pública de entrada
        ├── pages/
        │   ├── public/error.jsp
        │   └── secure/home.jsp           ← Página protegida post-login
        └── WEB-INF/
            ├── web.xml
            ├── ibm-web-ext.xml           ← Descriptor WAS9
            └── struts/
                └── struts-config.xml
```

---

## Configuración paso a paso

### 1. Registrar la aplicación en WSO2 IS

En WSO2 IS (Management Console o Console UI):
- Crear una **OAuth/OIDC Application**
- **Grant type**: Authorization Code
- **Callback URL**: `http://<servidor>:9080/struts-wso2-app/oidc/callback.do`
- **Post logout redirect URI**: `http://<servidor>:9080/struts-wso2-app/login.jsp`
- Anotar `client_id` y `client_secret`

Si usas claims personalizados (`member_of`, `axa-windowsID`):
- Ir a **Claims > Add Local Claim** y crear los claims
- En la app, en **User Attributes**, incluir esos claims en el scope `openid`

### 2. Editar OIDCConfig.java

```java
public static final String WSO2_BASE_URL  = "https://tu-wso2is:9443";
public static final String CLIENT_ID      = "TU_CLIENT_ID";
public static final String CLIENT_SECRET  = "TU_CLIENT_SECRET";
public static final String REDIRECT_URI   = "http://tu-servidor:9080/struts-wso2-app/oidc/callback.do";
```

### 3. Proxy corporativo (si aplica)

En `OIDCService.java`, método `buildHttpClient()`, descomenta y ajusta:

```java
HttpHost proxy = new HttpHost("proxy.corp.com", 8080);
return HttpClients.custom().setProxy(proxy).build();
```

Si el proxy usa certificados SSL corporativos, importa el CA al cacerts de WAS9:

```bash
keytool -importcert -alias AXA-Proxy-ROOT-CA \
        -file AXA-Proxy-ROOT-CA.crt \
        -keystore $WAS_HOME/java/8.0/jre/lib/security/cacerts \
        -storepass changeit
```

### 4. Compilar y empaquetar

```bash
mvn clean package -DskipTests
```

Genera: `target/struts-wso2-app.war`

### 5. Desplegar en WAS9

- **Admin Console** → Applications → New Application → New Enterprise Application
- Subir el WAR → Context root: `/struts-wso2-app`
- O vía `wsadmin`:

```python
AdminApp.install('struts-wso2-app.war',
  '[-contextroot /struts-wso2-app -appname struts-wso2-app]')
AdminConfig.save()
```

---

## Flujo de autenticación

```
Browser                App (Struts)              WSO2 IS
   |                       |                        |
   |-- GET /login.do ------>|                        |
   |                       |-- Redirect 302 -------->|
   |<-- 302 to WSO2 IS ----|  /oauth2/authorize      |
   |                                                 |
   |--------- Login en WSO2 IS (usuario/contraseña) ->|
   |<-- Redirect con ?code=...&state=... ------------|
   |                       |                        |
   |-- GET /oidc/callback ->|                        |
   |                       |-- POST /oauth2/token -->|
   |                       |<-- access_token, id_token|
   |                       |-- GET /oauth2/userinfo ->|
   |                       |<-- claims del usuario --|
   |                       |                        |
   |<-- Redirect /home.do --|                        |
   |                       |                        |
   |-- GET /logout.do ----->|                        |
   |                       |(invalida sesión local)  |
   |<-- Redirect /oidc/logout?id_token_hint=... ---->|
   |<-- Redirect post_logout_redirect_uri ------------|
```

---

## Notas sobre Struts 1.1

- El ActionServlet mapea `*.do`; el callback se llama como `/oidc/callback.do`
- Struts 1.1 **no tiene anotaciones**: todo va en `struts-config.xml`
- Los `ActionForm` no son necesarios si no hay formularios propios (OIDC no los usa)
