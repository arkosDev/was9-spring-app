<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://jakarta.apache.org/struts/tags-html"  prefix="html" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core"           prefix="c"    %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Struts WSO2 IS</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body class="login-page">

    <div class="login-card">
        <div class="login-logo">
            <span class="logo-icon">&#128274;</span>
            <h1>Portal Corporativo</h1>
            <p class="subtitle">Autenticación centralizada via WSO2 IS</p>
        </div>

        <!-- Mensaje de error si hay uno -->
        <c:if test="${not empty errorMsg}">
            <div class="alert alert-error">
                <span>&#9888;</span> ${errorMsg}
            </div>
        </c:if>

        <!-- Mensaje al regresar del logout -->
        <c:if test="${param.logout eq 'true'}">
            <div class="alert alert-info">
                <span>&#10003;</span> Sesión cerrada correctamente.
            </div>
        </c:if>

        <a href="${pageContext.request.contextPath}/login.do" class="btn-login">
            &#128275; Iniciar sesión con WSO2 IS
        </a>

        <p class="login-footer">
            Al iniciar sesión aceptas las políticas de seguridad corporativas.
        </p>
    </div>

</body>
</html>
