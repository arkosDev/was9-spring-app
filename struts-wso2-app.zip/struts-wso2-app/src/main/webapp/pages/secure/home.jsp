<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://jakarta.apache.org/struts/tags-html"  prefix="html" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core"           prefix="c"    %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Inicio - Portal Corporativo</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body class="home-page">

    <!-- ── Navbar ─────────────────────────────────────────── -->
    <nav class="navbar">
        <div class="nav-brand">&#128274; Portal Corporativo</div>
        <div class="nav-user">
            <span class="nav-username">
                &#128100; ${user.preferredUsername != null ? user.preferredUsername : user.name}
            </span>
            <a href="${pageContext.request.contextPath}/logout.do" class="btn-logout">
                &#128275; Cerrar sesión
            </a>
        </div>
    </nav>

    <!-- ── Contenido ──────────────────────────────────────── -->
    <main class="main-content">
        <div class="welcome-card">
            <h2>Bienvenido, <span class="highlight">${user.name}</span></h2>
            <p>Has iniciado sesión correctamente a través de WSO2 IS.</p>
        </div>

        <!-- Info del usuario -->
        <div class="info-grid">
            <div class="info-card">
                <h3>&#128100; Información del usuario</h3>
                <table class="info-table">
                    <tr>
                        <td class="label">Subject (sub)</td>
                        <td>${user.sub}</td>
                    </tr>
                    <tr>
                        <td class="label">Nombre</td>
                        <td>${user.name}</td>
                    </tr>
                    <tr>
                        <td class="label">Email</td>
                        <td>${user.email}</td>
                    </tr>
                    <tr>
                        <td class="label">Username</td>
                        <td>${user.preferredUsername}</td>
                    </tr>
                </table>
            </div>

            <!-- Claims personalizados WSO2 IS -->
            <div class="info-card">
                <h3>&#128203; Claims corporativos (WSO2 IS)</h3>
                <table class="info-table">
                    <tr>
                        <td class="label">member_of</td>
                        <td>
                            <c:choose>
                                <c:when test="${not empty user.memberOf}">
                                    <span class="badge">${user.memberOf}</span>
                                </c:when>
                                <c:otherwise>
                                    <span class="text-muted">—</span>
                                </c:otherwise>
                            </c:choose>
                        </td>
                    </tr>
                    <tr>
                        <td class="label">axa-windowsID</td>
                        <td>
                            <c:choose>
                                <c:when test="${not empty user.windowsId}">
                                    ${user.windowsId}
                                </c:when>
                                <c:otherwise>
                                    <span class="text-muted">—</span>
                                </c:otherwise>
                            </c:choose>
                        </td>
                    </tr>
                </table>
            </div>
        </div>

        <div class="action-bar">
            <a href="${pageContext.request.contextPath}/logout.do" class="btn-logout-big">
                &#128275; Cerrar sesión
            </a>
        </div>
    </main>

</body>
</html>
