package com.example.action;

import com.example.model.OIDCUser;
import com.example.util.OIDCConfig;
import com.example.util.OIDCService;
import net.minidev.json.JSONObject;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * OIDCCallbackAction
 *
 * WSO2 IS redirige aquí después del login con ?code=...&state=...
 *
 * Mapping en struts-config.xml:
 *   /oidc/callback  →  com.example.action.OIDCCallbackAction
 *
 * Forwardss esperados:
 *   success  →  /pages/secure/home.jsp
 *   error    →  /login.jsp
 */
public class OIDCCallbackAction extends Action {

    private static final Log LOG = LogFactory.getLog(OIDCCallbackAction.class);

    @Override
    public ActionForward execute(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response) throws Exception {

        HttpSession session = request.getSession(false);

        // ── 1. Validar state (CSRF) ───────────────────────────────────────────
        String returnedState = request.getParameter("state");
        String savedState    = (session != null)
                ? (String) session.getAttribute(OIDCConfig.SESSION_STATE)
                : null;

        if (returnedState == null || !returnedState.equals(savedState)) {
            LOG.warn("State inválido. Posible ataque CSRF.");
            request.setAttribute("errorMsg", "Sesión inválida. Por favor inicia sesión nuevamente.");
            return mapping.findForward("error");
        }

        // ── 2. Verificar si WSO2 IS devolvió error ────────────────────────────
        String error = request.getParameter("error");
        if (error != null) {
            LOG.warn("Error del IdP: " + error + " - " + request.getParameter("error_description"));
            request.setAttribute("errorMsg", "Error de autenticación: " + error);
            return mapping.findForward("error");
        }

        // ── 3. Obtener el authorization code ─────────────────────────────────
        String code = request.getParameter("code");
        if (code == null || code.isEmpty()) {
            request.setAttribute("errorMsg", "No se recibió código de autorización.");
            return mapping.findForward("error");
        }

        // ── 4. Intercambiar code por tokens ───────────────────────────────────
        JSONObject tokens;
        try {
            tokens = OIDCService.exchangeCodeForTokens(code);
        } catch (Exception e) {
            LOG.error("Error al intercambiar código por tokens", e);
            request.setAttribute("errorMsg", "Error al obtener tokens del IdP.");
            return mapping.findForward("error");
        }

        String accessToken  = (String) tokens.get("access_token");
        String idToken      = (String) tokens.get("id_token");

        if (accessToken == null) {
            LOG.error("access_token nulo en respuesta del IdP: " + tokens.toJSONString());
            request.setAttribute("errorMsg", "No se recibió access_token.");
            return mapping.findForward("error");
        }

        // ── 5. Obtener información del usuario (userinfo endpoint) ────────────
        OIDCUser user;
        try {
            user = OIDCService.fetchUserInfo(accessToken);
        } catch (Exception e) {
            LOG.error("Error al obtener userinfo", e);
            request.setAttribute("errorMsg", "No se pudo obtener información del usuario.");
            return mapping.findForward("error");
        }

        // ── 6. Guardar en sesión ──────────────────────────────────────────────
        if (session == null) session = request.getSession(true);
        session.removeAttribute(OIDCConfig.SESSION_STATE); // ya no necesitamos el state
        session.setAttribute(OIDCConfig.SESSION_USER,         user);
        session.setAttribute(OIDCConfig.SESSION_ACCESS_TOKEN, accessToken);
        session.setAttribute(OIDCConfig.SESSION_ID_TOKEN,     idToken);

        LOG.info("Usuario autenticado: " + user);

        return mapping.findForward("success");
    }
}
