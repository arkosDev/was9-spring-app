package com.example.action;

import com.example.util.OIDCConfig;
import com.example.util.OIDCService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * LoginAction
 *
 * Redirige al usuario al endpoint de autorización de WSO2 IS.
 * Mapping en struts-config.xml:
 *   /login  →  com.example.action.LoginAction
 */
public class LoginAction extends Action {

    private static final Log LOG = LogFactory.getLog(LoginAction.class);

    @Override
    public ActionForward execute(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response) throws Exception {

        HttpSession session = request.getSession(true);

        // Genera un state aleatorio y guárdalo en sesión (protección CSRF)
        String state = OIDCService.generateState();
        session.setAttribute(OIDCConfig.SESSION_STATE, state);

        // Construye la URL de autorización de WSO2 IS
        String authUrl = OIDCService.buildAuthorizationUrl(state);
        LOG.info("Redirigiendo a WSO2 IS: " + authUrl);

        // Redirige el browser al IdP
        response.sendRedirect(authUrl);
        return null; // ya manejamos la respuesta manualmente
    }
}
