package com.example.action;

import com.example.model.OIDCUser;
import com.example.util.OIDCConfig;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * HomeAction
 *
 * Página principal post-login. Solo llega aquí si AuthFilter
 * dejó pasar la petición (usuario autenticado en sesión).
 *
 * Mapping en struts-config.xml:
 *   /home  →  com.example.action.HomeAction
 *   forward success  →  /pages/secure/home.jsp
 */
public class HomeAction extends Action {

    @Override
    public ActionForward execute(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response) throws Exception {

        // El usuario ya viene en sesión; lo ponemos en request para la JSP
        OIDCUser user = (OIDCUser) request.getSession(false)
                                          .getAttribute(OIDCConfig.SESSION_USER);
        request.setAttribute("user", user);

        return mapping.findForward("success");
    }
}
