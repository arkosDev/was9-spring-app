package com.example.action;

import com.example.util.OIDCConfig;
import com.example.util.OIDCService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * LogoutAction
 *
 * 1. Invalida la sesión local.
 * 2. Redirige al RP-Initiated Logout de WSO2 IS (con id_token_hint).
 *
 * Mapping en struts-config.xml:
 *   /logout  →  com.example.action.LogoutAction
 */
public class LogoutAction extends Action {

    private static final Log LOG = LogFactory.getLog(LogoutAction.class);

    @Override
    public ActionForward execute(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response) throws Exception {

        HttpSession session = request.getSession(false);
        String idToken = null;

        if (session != null) {
            idToken = (String) session.getAttribute(OIDCConfig.SESSION_ID_TOKEN);
            session.invalidate(); // invalida la sesión local inmediatamente
            LOG.info("Sesión local invalidada.");
        }

        // Redirige al logout de WSO2 IS
        if (idToken != null) {
            String logoutUrl = OIDCService.buildLogoutUrl(idToken);
            LOG.info("Redirigiendo logout a WSO2 IS: " + logoutUrl);
            response.sendRedirect(logoutUrl);
        } else {
            // Sin id_token simplemente mandamos al login
            response.sendRedirect(request.getContextPath() + "/login.jsp");
        }

        return null; // respuesta manejada manualmente
    }
}
