package com.example.model;

import java.io.Serializable;

/**
 * Datos del usuario autenticado via OIDC.
 */
public class OIDCUser implements Serializable {

    private static final long serialVersionUID = 1L;

    private String sub;
    private String name;
    private String email;
    private String preferredUsername;
    private String memberOf;       // claim personalizado WSO2: member_of
    private String windowsId;      // claim personalizado WSO2: axa-windowsID

    public OIDCUser() {}

    // ── Getters / Setters ─────────────────────────────────────────────────────

    public String getSub()                  { return sub; }
    public void   setSub(String sub)        { this.sub = sub; }

    public String getName()                 { return name; }
    public void   setName(String name)      { this.name = name; }

    public String getEmail()                { return email; }
    public void   setEmail(String email)    { this.email = email; }

    public String getPreferredUsername()                          { return preferredUsername; }
    public void   setPreferredUsername(String preferredUsername)  { this.preferredUsername = preferredUsername; }

    public String getMemberOf()                   { return memberOf; }
    public void   setMemberOf(String memberOf)    { this.memberOf = memberOf; }

    public String getWindowsId()                  { return windowsId; }
    public void   setWindowsId(String windowsId)  { this.windowsId = windowsId; }

    @Override
    public String toString() {
        return "OIDCUser{sub='" + sub + "', name='" + name + "', email='" + email + "'}";
    }
}
