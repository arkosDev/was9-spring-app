package com.example.util;

import com.example.model.OIDCUser;
import net.minidev.json.JSONObject;
import net.minidev.json.parser.JSONParser;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

/**
 * Servicio OIDC Authorization Code Flow contra WSO2 IS.
 *
 * Flujo:
 *   1. buildAuthorizationUrl()  →  redirige el browser a WSO2 IS
 *   2. exchangeCodeForTokens()  →  intercambia el 'code' por tokens
 *   3. fetchUserInfo()          →  obtiene claims del usuario
 *   4. buildLogoutUrl()         →  cierra sesión en WSO2 IS
 */
public class OIDCService {

    private static final Log LOG = LogFactory.getLog(OIDCService.class);

    // ── 1. Authorization URL ───────────────────────────────────────────────────

    /**
     * Genera la URL de autorización y devuelve un state aleatorio
     * que debe guardarse en sesión para validación CSRF.
     */
    public static String generateState() {
        byte[] bytes = new byte[16];
        new SecureRandom().nextBytes(bytes);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }

    public static String buildAuthorizationUrl(String state) throws Exception {
        return OIDCConfig.AUTH_ENDPOINT
                + "?response_type=code"
                + "&client_id="     + URLEncoder.encode(OIDCConfig.CLIENT_ID, "UTF-8")
                + "&redirect_uri="  + URLEncoder.encode(OIDCConfig.REDIRECT_URI, "UTF-8")
                + "&scope="         + URLEncoder.encode(OIDCConfig.SCOPES, "UTF-8")
                + "&state="         + URLEncoder.encode(state, "UTF-8");
    }

    // ── 2. Token Exchange ──────────────────────────────────────────────────────

    /**
     * Intercambia el authorization code por access_token, id_token, refresh_token.
     * Devuelve el JSONObject crudo con los tokens.
     */
    public static JSONObject exchangeCodeForTokens(String code) throws Exception {
        CloseableHttpClient client = buildHttpClient();
        try {
            HttpPost post = new HttpPost(OIDCConfig.TOKEN_ENDPOINT);

            // Basic Auth header con client_id:client_secret
            String credentials = OIDCConfig.CLIENT_ID + ":" + OIDCConfig.CLIENT_SECRET;
            String encoded = Base64.getEncoder().encodeToString(
                    credentials.getBytes(StandardCharsets.UTF_8));
            post.setHeader("Authorization", "Basic " + encoded);
            post.setHeader("Content-Type", "application/x-www-form-urlencoded");

            List<NameValuePair> params = new ArrayList<NameValuePair>();
            params.add(new BasicNameValuePair("grant_type",   "authorization_code"));
            params.add(new BasicNameValuePair("code",          code));
            params.add(new BasicNameValuePair("redirect_uri",  OIDCConfig.REDIRECT_URI));
            post.setEntity(new UrlEncodedFormEntity(params, "UTF-8"));

            CloseableHttpResponse response = client.execute(post);
            try {
                String body = EntityUtils.toString(response.getEntity(), "UTF-8");
                LOG.debug("Token response: " + body);
                return (JSONObject) new JSONParser(JSONParser.MODE_PERMISSIVE).parse(body);
            } finally {
                response.close();
            }
        } finally {
            client.close();
        }
    }

    // ── 3. UserInfo ────────────────────────────────────────────────────────────

    /**
     * Llama al userinfo endpoint con el access_token y mapea los claims
     * al objeto OIDCUser (incluye claims personalizados de WSO2 IS).
     */
    public static OIDCUser fetchUserInfo(String accessToken) throws Exception {
        CloseableHttpClient client = buildHttpClient();
        try {
            HttpGet get = new HttpGet(OIDCConfig.USERINFO_ENDPOINT);
            get.setHeader("Authorization", "Bearer " + accessToken);

            CloseableHttpResponse response = client.execute(get);
            try {
                String body = EntityUtils.toString(response.getEntity(), "UTF-8");
                LOG.debug("UserInfo response: " + body);

                JSONObject json = (JSONObject) new JSONParser(JSONParser.MODE_PERMISSIVE).parse(body);

                OIDCUser user = new OIDCUser();
                user.setSub(              getStr(json, "sub"));
                user.setName(             getStr(json, "name"));
                user.setEmail(            getStr(json, "email"));
                user.setPreferredUsername(getStr(json, "preferred_username"));
                // ── Claims personalizados WSO2 IS ──
                user.setMemberOf( getStr(json, "member_of"));
                user.setWindowsId(getStr(json, "axa-windowsID"));

                return user;
            } finally {
                response.close();
            }
        } finally {
            client.close();
        }
    }

    // ── 4. Logout URL ─────────────────────────────────────────────────────────

    /**
     * Construye la URL de logout de WSO2 IS (RP-Initiated Logout).
     * Incluye id_token_hint para que WSO2 sepa qué sesión cerrar.
     */
    public static String buildLogoutUrl(String idToken) throws Exception {
        String url = OIDCConfig.LOGOUT_ENDPOINT
                + "?id_token_hint="             + URLEncoder.encode(idToken, "UTF-8")
                + "&post_logout_redirect_uri="  + URLEncoder.encode(OIDCConfig.POST_LOGOUT_REDIRECT, "UTF-8");
        return url;
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private static String getStr(JSONObject json, String key) {
        Object val = json.get(key);
        return val != null ? val.toString() : null;
    }

    /**
     * Construye el HttpClient.
     * Si tu entorno tiene proxy corporativo configura aquí:
     *   HttpHost proxy = new HttpHost("proxy.corp.com", 8080);
     *   return HttpClients.custom().setProxy(proxy).build();
     */
    private static CloseableHttpClient buildHttpClient() {
        return HttpClients.createDefault();
    }
}
