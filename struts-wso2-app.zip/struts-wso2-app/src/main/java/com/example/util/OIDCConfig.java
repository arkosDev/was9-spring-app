package com.example.util;

/**
 * Configuración OIDC para WSO2 IS 7.x
 * Ajusta los valores según tu instancia.
 */
public class OIDCConfig {

    // ── WSO2 IS base URL ──────────────────────────────────────────────────────
    public static final String WSO2_BASE_URL        = "https://wso2is.example.com:9443";
    public static final String TENANT               = "carbon.super"; // o tu tenant

    // ── OIDC endpoints ────────────────────────────────────────────────────────
    public static final String AUTH_ENDPOINT        = WSO2_BASE_URL + "/oauth2/authorize";
    public static final String TOKEN_ENDPOINT       = WSO2_BASE_URL + "/oauth2/token";
    public static final String USERINFO_ENDPOINT    = WSO2_BASE_URL + "/oauth2/userinfo";
    public static final String LOGOUT_ENDPOINT      = WSO2_BASE_URL + "/oidc/logout";
    public static final String JWKS_URI             = WSO2_BASE_URL + "/oauth2/jwks";

    // ── Aplicación registrada en WSO2 IS ─────────────────────────────────────
    public static final String CLIENT_ID            = "YOUR_CLIENT_ID";
    public static final String CLIENT_SECRET        = "YOUR_CLIENT_SECRET";

    // ── Redirect URIs (deben coincidir con lo registrado en WSO2 IS) ─────────
    // Ejemplo: http://localhost:9080/struts-wso2-app/oidc/callback
    public static final String REDIRECT_URI         = "http://localhost:9080/struts-wso2-app/oidc/callback";
    public static final String POST_LOGOUT_REDIRECT = "http://localhost:9080/struts-wso2-app/login.jsp";

    // ── OAuth2 scopes ─────────────────────────────────────────────────────────
    public static final String SCOPES               = "openid profile email";

    // ── Session keys ──────────────────────────────────────────────────────────
    public static final String SESSION_USER         = "OIDC_USER";
    public static final String SESSION_ID_TOKEN     = "OIDC_ID_TOKEN";
    public static final String SESSION_ACCESS_TOKEN = "OIDC_ACCESS_TOKEN";
    public static final String SESSION_STATE        = "OIDC_STATE";

    private OIDCConfig() {}
}
