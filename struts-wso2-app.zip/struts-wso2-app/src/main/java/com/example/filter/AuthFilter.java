package com.example.filter;

import com.example.util.OIDCConfig;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * AuthFilter
 *
 * Intercepta todas las URLs bajo /pages/secure/*
 * Si no hay usuario en sesión, redirige al login OIDC.
 *
 * Configurado en web.xml.
 */
public class AuthFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {}

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest  request  = (HttpServletRequest)  req;
        HttpServletResponse response = (HttpServletResponse) res;

        HttpSession session = request.getSession(false);
        boolean authenticated = session != null
                && session.getAttribute(OIDCConfig.SESSION_USER) != null;

        if (authenticated) {
            chain.doFilter(req, res);
        } else {
            // Redirige al Action de login que a su vez va a WSO2 IS
            response.sendRedirect(request.getContextPath() + "/login.do");
        }
    }

    @Override
    public void destroy() {}
}
