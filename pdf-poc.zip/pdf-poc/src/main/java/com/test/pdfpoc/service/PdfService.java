package com.test.pdfpoc.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

@Service
public class PdfService {

    private static final Logger logger = LoggerFactory.getLogger(PdfService.class);

    public static ByteArrayOutputStream generaPDF(String repository) throws Exception {

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        HttpsURLConnection conn = null;

        try {
            final SSLContext sslContext = SSLContext.getInstance("TLSv1.2");
            sslContext.init(null, null, null);
            final SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();

            URL url = new URL(repository);
            conn = (HttpsURLConnection) url.openConnection();
            conn.setSSLSocketFactory(sslSocketFactory);
            conn.setDoOutput(true);
            conn.setRequestMethod("GET");
            conn.connect();

            int responseCode = conn.getResponseCode();

            if (responseCode == HttpURLConnection.HTTP_OK) {
                try (InputStream inputStream = conn.getInputStream()) {
                    byte[] buffer = new byte[4096];
                    int bytesRead;
                    while ((bytesRead = inputStream.read(buffer)) != -1) {
                        baos.write(buffer, 0, bytesRead);
                    }
                }
            } else {
                try (InputStream errorStream = conn.getErrorStream()) {
                    if (errorStream != null) {
                        try (BufferedReader reader = new BufferedReader(new InputStreamReader(errorStream))) {
                            String line;
                            while ((line = reader.readLine()) != null) {
                                logger.info(line);
                            }
                        }
                    }
                }
                logger.error("Response code: " + responseCode);
            }

        } catch (Exception e) {
            logger.error("Error conexion repositorio PolizaPDF: " + e);
            throw e;
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }

        return baos;
    }
}
