package com.test.pdfpoc.controller;

import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.nio.file.Files;

/**
 * Simula el repositorio externo que expone el PDF por HTTPS,
 * para que PdfController -> PdfService.generaPDF tenga algo real contra que conectarse.
 */
@RestController
public class RepositoryController {

    @GetMapping("/repository/dummy.pdf")
    public ResponseEntity<byte[]> dummyPdf() throws IOException {
        ClassPathResource resource = new ClassPathResource("dummy.pdf");
        byte[] pdfBytes = Files.readAllBytes(resource.getFile().toPath());

        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_PDF)
                .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=dummy.pdf")
                .body(pdfBytes);
    }
}
