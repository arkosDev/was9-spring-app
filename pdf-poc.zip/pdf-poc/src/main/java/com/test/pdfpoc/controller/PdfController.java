package com.test.pdfpoc.controller;

import com.test.pdfpoc.service.PdfService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.ByteArrayOutputStream;

@RestController
public class PdfController {

    // Ejemplo de repository publico solo para probar la descarga:
    // https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf
    @GetMapping("/pdf")
    public ResponseEntity<byte[]> descargarPdf(@RequestParam String repository) throws Exception {
        ByteArrayOutputStream baos = PdfService.generaPDF(repository);

        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_PDF)
                .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=documento.pdf")
                .body(baos.toByteArray());
    }
}
