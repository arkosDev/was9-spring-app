Dummy repository de PDF

Que hace
--------
Levanta un endpoint HTTPS que regresa un PDF real, para que le apuntes tu generaPDF
(el que ya tienes en tu otro proyecto) y pruebes la conexion.

    GET https://localhost:8443/repository/dummy.pdf

Certificado
-----------
Es self-signed (keystore.p12 incluido). Tu cliente (donde corre tu generaPDF) tiene
que confiar en el, si no vas a tronar con PKIX path building failed.
Importa pdfpoc-cert.crt al cacerts del JDK que use tu proyecto:

    keytool -importcert -alias pdfpoc -file pdfpoc-cert.crt \
      -keystore "$JAVA_HOME/lib/security/cacerts" -storepass changeit -noprompt

Como correrlo
--------------
1. mvn spring-boot:run
2. Prueba directo: https://localhost:8443/repository/dummy.pdf
3. Apunta tu generaPDF(repository) a esa misma URL.
