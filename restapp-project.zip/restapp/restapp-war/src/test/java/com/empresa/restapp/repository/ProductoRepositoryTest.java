package com.empresa.restapp.repository;

import com.empresa.restapp.model.Producto;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class ProductoRepositoryTest {

    @Mock
    private JdbcTemplate jdbcTemplate;

    @InjectMocks
    private ProductoRepository productoRepository;

    private Producto productoEjemplo;

    @Before
    public void setUp() {
        productoEjemplo = new Producto(1L, "Laptop", "Laptop 15 pulgadas", 12999.99, 10);
    }

    // ----------------------------------------------------------------
    // findAll
    // ----------------------------------------------------------------

    @Test
    public void findAll_retornaListaDeProductos() {
        List<Producto> esperado = Arrays.asList(
                productoEjemplo,
                new Producto(2L, "Mouse", "Mouse inalámbrico", 299.00, 50)
        );

        when(jdbcTemplate.query(anyString(), any(ProductoRowMapper.class)))
                .thenReturn(esperado);

        List<Producto> resultado = productoRepository.findAll();

        assertNotNull(resultado);
        assertEquals(2, resultado.size());
        assertEquals("Laptop", resultado.get(0).getNombre());
        verify(jdbcTemplate, times(1)).query(anyString(), any(ProductoRowMapper.class));
    }

    @Test
    public void findAll_retornaListaVacia_cuandoNoHayRegistros() {
        when(jdbcTemplate.query(anyString(), any(ProductoRowMapper.class)))
                .thenReturn(Collections.<Producto>emptyList());

        List<Producto> resultado = productoRepository.findAll();

        assertNotNull(resultado);
        assertTrue(resultado.isEmpty());
    }

    // ----------------------------------------------------------------
    // findById
    // ----------------------------------------------------------------

    @Test
    public void findById_retornaProducto_cuandoExiste() {
        when(jdbcTemplate.query(anyString(), any(ProductoRowMapper.class), eq(1L)))
                .thenReturn(Arrays.asList(productoEjemplo));

        Producto resultado = productoRepository.findById(1L);

        assertNotNull(resultado);
        assertEquals(Long.valueOf(1L), resultado.getId());
        assertEquals("Laptop", resultado.getNombre());
    }

    @Test
    public void findById_retornaNull_cuandoNoExiste() {
        when(jdbcTemplate.query(anyString(), any(ProductoRowMapper.class), eq(99L)))
                .thenReturn(Collections.<Producto>emptyList());

        Producto resultado = productoRepository.findById(99L);

        assertNull(resultado);
    }

    // ----------------------------------------------------------------
    // insert
    // ----------------------------------------------------------------

    @Test
    public void insert_ejecutaUpdateConParametrosCorrectos() {
        when(jdbcTemplate.update(anyString(),
                eq("Laptop"), eq("Laptop 15 pulgadas"), eq(12999.99), eq(10)))
                .thenReturn(1);

        int filas = productoRepository.insert(productoEjemplo);

        assertEquals(1, filas);
        verify(jdbcTemplate, times(1)).update(anyString(),
                eq("Laptop"), eq("Laptop 15 pulgadas"), eq(12999.99), eq(10));
    }

    // ----------------------------------------------------------------
    // update
    // ----------------------------------------------------------------

    @Test
    public void update_ejecutaUpdateConIdCorrecto() {
        when(jdbcTemplate.update(anyString(),
                eq("Laptop"), eq("Laptop 15 pulgadas"), eq(12999.99), eq(10), eq(1L)))
                .thenReturn(1);

        int filas = productoRepository.update(productoEjemplo);

        assertEquals(1, filas);
    }

    @Test
    public void update_retornaCero_cuandoNoExisteElId() {
        when(jdbcTemplate.update(anyString(),
                any(), any(), any(), any(), eq(999L)))
                .thenReturn(0);

        Producto noExiste = new Producto(999L, "X", "Y", 1.0, 0);
        int filas = productoRepository.update(noExiste);

        assertEquals(0, filas);
    }

    // ----------------------------------------------------------------
    // delete
    // ----------------------------------------------------------------

    @Test
    public void delete_ejecutaUpdateConIdCorrecto() {
        when(jdbcTemplate.update(anyString(), eq(1L))).thenReturn(1);

        int filas = productoRepository.delete(1L);

        assertEquals(1, filas);
        verify(jdbcTemplate, times(1)).update(anyString(), eq(1L));
    }

    @Test
    public void delete_retornaCero_cuandoNoExisteElId() {
        when(jdbcTemplate.update(anyString(), eq(999L))).thenReturn(0);

        int filas = productoRepository.delete(999L);

        assertEquals(0, filas);
    }
}
