package com.empresa.restapp.service;

import com.empresa.restapp.model.Producto;
import com.empresa.restapp.repository.ProductoRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class ProductoServiceTest {

    @Mock
    private ProductoRepository productoRepository;

    @InjectMocks
    private ProductoService productoService;

    private Producto p1;
    private Producto p2;

    @Before
    public void setUp() {
        p1 = new Producto(1L, "Laptop",  "Laptop 15\"",      12999.99, 10);
        p2 = new Producto(2L, "Monitor", "Monitor 27\" 4K",   8500.00, 5);
    }

    // ----------------------------------------------------------------
    // listarTodos
    // ----------------------------------------------------------------

    @Test
    public void listarTodos_delegaEnRepositorio() {
        when(productoRepository.findAll()).thenReturn(Arrays.asList(p1, p2));

        List<Producto> resultado = productoService.listarTodos();

        assertNotNull(resultado);
        assertEquals(2, resultado.size());
        verify(productoRepository, times(1)).findAll();
    }

    @Test
    public void listarTodos_nuncaRetornaNull() {
        when(productoRepository.findAll()).thenReturn(Arrays.<Producto>asList());

        List<Producto> resultado = productoService.listarTodos();

        assertNotNull(resultado);
        assertTrue(resultado.isEmpty());
    }

    // ----------------------------------------------------------------
    // obtenerPorId
    // ----------------------------------------------------------------

    @Test
    public void obtenerPorId_retornaProducto_cuandoExiste() {
        when(productoRepository.findById(1L)).thenReturn(p1);

        Producto resultado = productoService.obtenerPorId(1L);

        assertNotNull(resultado);
        assertEquals("Laptop", resultado.getNombre());
        verify(productoRepository, times(1)).findById(1L);
    }

    @Test
    public void obtenerPorId_retornaNull_cuandoNoExiste() {
        when(productoRepository.findById(99L)).thenReturn(null);

        Producto resultado = productoService.obtenerPorId(99L);

        assertNull(resultado);
    }

    // ----------------------------------------------------------------
    // crear
    // ----------------------------------------------------------------

    @Test
    public void crear_invocaInsertUnaVez() {
        Producto nuevo = new Producto(null, "Teclado", "Teclado mecánico", 750.00, 20);

        productoService.crear(nuevo);

        verify(productoRepository, times(1)).insert(nuevo);
    }

    @Test
    public void crear_noPasaIdAlRepositorio() {
        // El repositorio genera el id; el service no debe asignarlo
        Producto nuevo = new Producto(null, "Audífonos", "BT 5.0", 450.00, 15);

        productoService.crear(nuevo);

        assertNull(nuevo.getId()); // el service no debe modificar el objeto
        verify(productoRepository).insert(nuevo);
    }

    // ----------------------------------------------------------------
    // actualizar
    // ----------------------------------------------------------------

    @Test
    public void actualizar_invocaUpdateUnaVez() {
        productoService.actualizar(p1);

        verify(productoRepository, times(1)).update(p1);
    }

    @Test
    public void actualizar_propagaElMismoObjeto() {
        productoService.actualizar(p2);

        verify(productoRepository).update(p2);
        verifyNoMoreInteractions(productoRepository);
    }

    // ----------------------------------------------------------------
    // eliminar
    // ----------------------------------------------------------------

    @Test
    public void eliminar_invocaDeleteUnaVez() {
        productoService.eliminar(1L);

        verify(productoRepository, times(1)).delete(1L);
    }

    @Test
    public void eliminar_noInteractuaConOtroMetodo() {
        productoService.eliminar(2L);

        verify(productoRepository).delete(2L);
        verifyNoMoreInteractions(productoRepository);
    }
}
