package com.empresa.restapp.controller;

import com.empresa.restapp.model.Producto;
import com.empresa.restapp.service.ProductoService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Arrays;
import java.util.Collections;

import static org.hamcrest.Matchers.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Prueba el ProductoController de forma standalone (sin contexto Spring completo).
 * MockMvc simula las peticiones HTTP y valida respuestas JSON.
 */
@RunWith(MockitoJUnitRunner.class)
public class ProductoControllerTest {

    @Mock
    private ProductoService productoService;

    @InjectMocks
    private ProductoController productoController;

    private MockMvc mockMvc;
    private ObjectMapper objectMapper;

    private Producto p1;
    private Producto p2;

    @Before
    public void setUp() {
        // Construcción standalone: no levanta contexto Spring completo
        mockMvc = MockMvcBuilders.standaloneSetup(productoController).build();
        objectMapper = new ObjectMapper();

        p1 = new Producto(1L, "Laptop",  "Laptop 15\"",     12999.99, 10);
        p2 = new Producto(2L, "Monitor", "Monitor 27\" 4K",  8500.00,  5);
    }

    // ----------------------------------------------------------------
    // GET /productos
    // ----------------------------------------------------------------

    @Test
    public void getProductos_retorna200ConListaJSON() throws Exception {
        when(productoService.listarTodos()).thenReturn(Arrays.asList(p1, p2));

        mockMvc.perform(get("/productos")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].id",     is(1)))
                .andExpect(jsonPath("$[0].nombre", is("Laptop")))
                .andExpect(jsonPath("$[1].id",     is(2)))
                .andExpect(jsonPath("$[1].nombre", is("Monitor")));

        verify(productoService, times(1)).listarTodos();
    }

    @Test
    public void getProductos_retorna200ConListaVacia() throws Exception {
        when(productoService.listarTodos())
                .thenReturn(Collections.<Producto>emptyList());

        mockMvc.perform(get("/productos")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(0)));
    }

    // ----------------------------------------------------------------
    // GET /productos/{id}
    // ----------------------------------------------------------------

    @Test
    public void getProductoPorId_retorna200_cuandoExiste() throws Exception {
        when(productoService.obtenerPorId(1L)).thenReturn(p1);

        mockMvc.perform(get("/productos/1")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id",          is(1)))
                .andExpect(jsonPath("$.nombre",       is("Laptop")))
                .andExpect(jsonPath("$.precio",       is(12999.99)))
                .andExpect(jsonPath("$.stock",        is(10)));
    }

    @Test
    public void getProductoPorId_retorna404_cuandoNoExiste() throws Exception {
        when(productoService.obtenerPorId(99L)).thenReturn(null);

        mockMvc.perform(get("/productos/99")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }

    // ----------------------------------------------------------------
    // POST /productos
    // ----------------------------------------------------------------

    @Test
    public void postProducto_retorna201_cuandoCreacionExitosa() throws Exception {
        Producto nuevo = new Producto(null, "Teclado", "Mecánico TKL", 750.00, 20);
        doNothing().when(productoService).crear(any(Producto.class));

        mockMvc.perform(post("/productos")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(nuevo)))
                .andExpect(status().isCreated());

        verify(productoService, times(1)).crear(any(Producto.class));
    }

    @Test
    public void postProducto_invocaServiceConBodyCorrecto() throws Exception {
        Producto nuevo = new Producto(null, "Webcam", "1080p 30fps", 450.00, 30);
        doNothing().when(productoService).crear(any(Producto.class));

        mockMvc.perform(post("/productos")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(nuevo)))
                .andExpect(status().isCreated());

        verify(productoService).crear(argThat(p ->
                "Webcam".equals(p.getNombre()) && p.getPrecio() == 450.00
        ));
    }

    // ----------------------------------------------------------------
    // PUT /productos/{id}
    // ----------------------------------------------------------------

    @Test
    public void putProducto_retorna200_cuandoActualizacionExitosa() throws Exception {
        doNothing().when(productoService).actualizar(any(Producto.class));

        mockMvc.perform(put("/productos/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(p1)))
                .andExpect(status().isOk());

        verify(productoService, times(1)).actualizar(any(Producto.class));
    }

    @Test
    public void putProducto_asignaIdDeLaUrl() throws Exception {
        // El controller debe setear el id del path variable en el objeto
        Producto sinId = new Producto(null, "Laptop Pro", "Laptop 17\"", 15999.99, 5);
        doNothing().when(productoService).actualizar(any(Producto.class));

        mockMvc.perform(put("/productos/7")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(sinId)))
                .andExpect(status().isOk());

        verify(productoService).actualizar(argThat(p -> Long.valueOf(7L).equals(p.getId())));
    }

    // ----------------------------------------------------------------
    // DELETE /productos/{id}
    // ----------------------------------------------------------------

    @Test
    public void deleteProducto_retorna204() throws Exception {
        doNothing().when(productoService).eliminar(eq(1L));

        mockMvc.perform(delete("/productos/1"))
                .andExpect(status().isNoContent());

        verify(productoService, times(1)).eliminar(1L);
    }

    @Test
    public void deleteProducto_invocaServiceConIdCorrecto() throws Exception {
        doNothing().when(productoService).eliminar(eq(5L));

        mockMvc.perform(delete("/productos/5"))
                .andExpect(status().isNoContent());

        verify(productoService).eliminar(5L);
        verifyNoMoreInteractions(productoService);
    }
}
