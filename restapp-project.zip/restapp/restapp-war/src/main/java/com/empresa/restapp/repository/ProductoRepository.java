package com.empresa.restapp.repository;

import com.empresa.restapp.model.Producto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repositorio de Producto usando Spring JdbcTemplate.
 * Ajusta los nombres de tabla y columnas según tu esquema.
 */
@Repository
public class ProductoRepository {

    private static final String SQL_FIND_ALL =
            "SELECT id, nombre, descripcion, precio, stock FROM producto";

    private static final String SQL_FIND_BY_ID =
            "SELECT id, nombre, descripcion, precio, stock FROM producto WHERE id = ?";

    private static final String SQL_INSERT =
            "INSERT INTO producto (nombre, descripcion, precio, stock) VALUES (?, ?, ?, ?)";

    private static final String SQL_UPDATE =
            "UPDATE producto SET nombre = ?, descripcion = ?, precio = ?, stock = ? WHERE id = ?";

    private static final String SQL_DELETE =
            "DELETE FROM producto WHERE id = ?";

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public List<Producto> findAll() {
        return jdbcTemplate.query(SQL_FIND_ALL, new ProductoRowMapper());
    }

    public Producto findById(Long id) {
        List<Producto> result = jdbcTemplate.query(SQL_FIND_BY_ID, new ProductoRowMapper(), id);
        return result.isEmpty() ? null : result.get(0);
    }

    public int insert(Producto p) {
        return jdbcTemplate.update(SQL_INSERT,
                p.getNombre(),
                p.getDescripcion(),
                p.getPrecio(),
                p.getStock());
    }

    public int update(Producto p) {
        return jdbcTemplate.update(SQL_UPDATE,
                p.getNombre(),
                p.getDescripcion(),
                p.getPrecio(),
                p.getStock(),
                p.getId());
    }

    public int delete(Long id) {
        return jdbcTemplate.update(SQL_DELETE, id);
    }
}
