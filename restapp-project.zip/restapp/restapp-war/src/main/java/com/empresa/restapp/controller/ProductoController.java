package com.empresa.restapp.controller;

import com.empresa.restapp.model.Producto;
import com.empresa.restapp.service.ProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST Controller para el recurso Producto.
 *
 * Base URL:  /restapp/api/productos
 *
 * GET    /restapp/api/productos        -> listar todos
 * GET    /restapp/api/productos/{id}   -> buscar por id
 * POST   /restapp/api/productos        -> crear
 * PUT    /restapp/api/productos/{id}   -> actualizar
 * DELETE /restapp/api/productos/{id}   -> eliminar
 */
@RestController
@RequestMapping("/productos")
public class ProductoController {

    @Autowired
    private ProductoService productoService;

    // ---- GET todos ----
    @GetMapping
    public ResponseEntity<List<Producto>> listar() {
        List<Producto> lista = productoService.listarTodos();
        return ResponseEntity.ok(lista);
    }

    // ---- GET por id ----
    @GetMapping("/{id}")
    public ResponseEntity<Producto> obtener(@PathVariable("id") Long id) {
        Producto p = productoService.obtenerPorId(id);
        if (p == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        return ResponseEntity.ok(p);
    }

    // ---- POST crear ----
    @PostMapping
    public ResponseEntity<Void> crear(@RequestBody Producto producto) {
        productoService.crear(producto);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    // ---- PUT actualizar ----
    @PutMapping("/{id}")
    public ResponseEntity<Void> actualizar(
            @PathVariable("id") Long id,
            @RequestBody Producto producto) {
        producto.setId(id);
        productoService.actualizar(producto);
        return ResponseEntity.ok().build();
    }

    // ---- DELETE eliminar ----
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable("id") Long id) {
        productoService.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}
