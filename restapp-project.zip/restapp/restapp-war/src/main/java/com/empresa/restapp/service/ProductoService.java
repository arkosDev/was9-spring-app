package com.empresa.restapp.service;

import com.empresa.restapp.model.Producto;
import com.empresa.restapp.repository.ProductoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class ProductoService {

    @Autowired
    private ProductoRepository productoRepository;

    @Transactional(readOnly = true)
    public List<Producto> listarTodos() {
        return productoRepository.findAll();
    }

    @Transactional(readOnly = true)
    public Producto obtenerPorId(Long id) {
        return productoRepository.findById(id);
    }

    @Transactional
    public void crear(Producto producto) {
        productoRepository.insert(producto);
    }

    @Transactional
    public void actualizar(Producto producto) {
        productoRepository.update(producto);
    }

    @Transactional
    public void eliminar(Long id) {
        productoRepository.delete(id);
    }
}
