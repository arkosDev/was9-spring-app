<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://jakarta.apache.org/struts/tags-html"    prefix="html" %>
<%@ taglib uri="http://jakarta.apache.org/struts/tags-bean"    prefix="bean" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core"             prefix="c"    %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Login - Portal</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body class="login-page">

    <div class="login-card">
        <div class="login-logo">
            <span class="logo-icon">&#128274;</span>
            <h1>Portal Corporativo</h1>
        </div>

        <html:errors/>

        <html:form action="/login" method="post">
            <div class="form-group">
                <label for="username">Usuario</label>
                <html:text property="username" styleId="username" styleClass="form-input" maxlength="50"/>
            </div>
            <div class="form-group">
                <label for="password">Contraseña</label>
                <html:password property="password" styleId="password" styleClass="form-input" maxlength="50"/>
            </div>
            <html:submit styleClass="btn-login" value="Iniciar sesión"/>
        </html:form>
    </div>

</body>
</html>
