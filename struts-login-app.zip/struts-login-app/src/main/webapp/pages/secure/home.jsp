<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Inicio - Portal</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body class="home-page">

    <nav class="navbar">
        <div class="nav-brand">&#128274; Portal Corporativo</div>
        <div class="nav-user">
            <span class="nav-username">&#128100; ${usuario.nombre}</span>
            <a href="${pageContext.request.contextPath}/logout.do" class="btn-logout">
                &#128275; Cerrar sesión
            </a>
        </div>
    </nav>

    <main class="main-content">
        <div class="welcome-card">
            <h2>Bienvenido, <span class="highlight">${usuario.nombre}</span></h2>
        </div>

        <div class="info-grid">
            <div class="info-card">
                <h3>&#128100; Información</h3>
                <table class="info-table">
                    <tr>
                        <td class="label">Usuario</td>
                        <td>${usuario.username}</td>
                    </tr>
                    <tr>
                        <td class="label">Nombre</td>
                        <td>${usuario.nombre}</td>
                    </tr>
                    <tr>
                        <td class="label">Rol</td>
                        <td><span class="badge">${usuario.rol}</span></td>
                    </tr>
                </table>
            </div>
        </div>

        <div class="action-bar">
            <a href="${pageContext.request.contextPath}/logout.do" class="btn-logout-big">
                &#128275; Cerrar sesión
            </a>
        </div>
    </main>

</body>
</html>
