<%@ page contentType="text/html;charset=UTF-8" language="java" isErrorPage="true" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Error - Portal</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body class="login-page">
    <div class="login-card">
        <div class="login-logo">
            <span class="logo-icon">&#9888;</span>
            <h1>Error</h1>
        </div>
        <div class="alert alert-error">
            <c:choose>
                <c:when test="${not empty errorMsg}">${errorMsg}</c:when>
                <c:otherwise>Ocurrió un error inesperado.</c:otherwise>
            </c:choose>
        </div>
        <a href="${pageContext.request.contextPath}/login.jsp" class="btn-login">
            &#8592; Volver al login
        </a>
    </div>
</body>
</html>
