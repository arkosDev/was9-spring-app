package com.example.model;

import java.io.Serializable;

public class Usuario implements Serializable {

    private static final long serialVersionUID = 1L;

    private String username;
    private String nombre;
    private String rol;

    public Usuario() {}

    public Usuario(String username, String nombre, String rol) {
        this.username = username;
        this.nombre   = nombre;
        this.rol      = rol;
    }

    public String getUsername()              { return username; }
    public void   setUsername(String u)      { this.username = u; }

    public String getNombre()                { return nombre; }
    public void   setNombre(String n)        { this.nombre = n; }

    public String getRol()                   { return rol; }
    public void   setRol(String r)           { this.rol = r; }
}
