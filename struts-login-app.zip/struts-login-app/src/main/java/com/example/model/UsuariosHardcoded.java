package com.example.model;

import java.util.HashMap;
import java.util.Map;

/**
 * Usuarios hardcoded para desarrollo.
 * Clave: username  Valor: password|nombre|rol
 */
public class UsuariosHardcoded {

    private static final Map<String, String[]> USUARIOS = new HashMap<String, String[]>();

    static {
        USUARIOS.put("admin",   new String[]{"admin123",  "Administrador",  "ADMIN"});
        USUARIOS.put("usuario", new String[]{"user123",   "Usuario Normal", "USER"});
        USUARIOS.put("visor",   new String[]{"visor123",  "Solo Lectura",   "VISOR"});
    }

    public static Usuario autenticar(String username, String password) {
        String[] datos = USUARIOS.get(username);
        if (datos != null && datos[0].equals(password)) {
            return new Usuario(username, datos[1], datos[2]);
        }
        return null;
    }

    private UsuariosHardcoded() {}
}
