package com.example.action;

import com.example.form.LoginForm;
import com.example.model.Usuario;
import com.example.model.UsuariosHardcoded;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LoginAction extends Action {

    private static final Log LOG = LogFactory.getLog(LoginAction.class);

    public static final String SESSION_USUARIO = "USUARIO_SESION";

    @Override
    public ActionForward execute(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response) throws Exception {

        LoginForm loginForm = (LoginForm) form;

        Usuario usuario = UsuariosHardcoded.autenticar(
                loginForm.getUsername(), loginForm.getPassword());

        if (usuario == null) {
            LOG.warn("Login fallido para: " + loginForm.getUsername());
            ActionMessages errors = new ActionMessages();
            errors.add(ActionMessages.GLOBAL_MESSAGE,
                       new ActionMessage("error.credenciales.invalidas"));
            saveErrors(request, errors);
            return mapping.findForward("error");
        }

        HttpSession session = request.getSession(true);
        session.setAttribute(SESSION_USUARIO, usuario);
        LOG.info("Login exitoso: " + usuario.getUsername());

        return mapping.findForward("success");
    }
}
