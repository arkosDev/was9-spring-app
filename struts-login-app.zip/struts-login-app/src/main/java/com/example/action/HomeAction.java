package com.example.action;

import com.example.model.Usuario;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class HomeAction extends Action {

    @Override
    public ActionForward execute(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response) throws Exception {

        Usuario usuario = (Usuario) request.getSession(false)
                                           .getAttribute(LoginAction.SESSION_USUARIO);
        request.setAttribute("usuario", usuario);

        return mapping.findForward("success");
    }
}
