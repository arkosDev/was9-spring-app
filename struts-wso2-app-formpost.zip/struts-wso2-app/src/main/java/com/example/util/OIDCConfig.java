package com.example.util;

public class OIDCConfig {

    public static final String WSO2_BASE_URL        = "https://localhost:9444";
    public static final String AUTH_ENDPOINT        = WSO2_BASE_URL + "/oauth2/authorize";
    public static final String LOGOUT_ENDPOINT      = WSO2_BASE_URL + "/oidc/logout";

    public static final String CLIENT_ID            = "YOUR_CLIENT_ID";
    public static final String CLIENT_SECRET        = "YOUR_CLIENT_SECRET";

    public static final String REDIRECT_URI         = "http://localhost:9080/adrc/oidc/callback.do";
    public static final String POST_LOGOUT_REDIRECT = "http://localhost:9080/adrc/login.jsp";

    // form_post: WSO2 IS hace POST al callback con los tokens como parámetros
    public static final String RESPONSE_TYPE        = "id_token token";
    public static final String RESPONSE_MODE        = "form_post";
    public static final String SCOPES               = "openid profile email";

    public static final String SESSION_USER         = "OIDC_USER";
    public static final String SESSION_ID_TOKEN     = "OIDC_ID_TOKEN";
    public static final String SESSION_ACCESS_TOKEN = "OIDC_ACCESS_TOKEN";
    public static final String SESSION_STATE        = "OIDC_STATE";

    private OIDCConfig() {}
}
