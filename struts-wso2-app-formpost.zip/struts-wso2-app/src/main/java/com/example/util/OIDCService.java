package com.example.util;

import com.example.model.OIDCUser;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.net.URLEncoder;
import java.security.SecureRandom;
import java.util.Base64;

public class OIDCService {

    private static final Log LOG = LogFactory.getLog(OIDCService.class);

    // ── State ─────────────────────────────────────────────────────────────────

    public static String generateState() {
        byte[] bytes = new byte[16];
        new SecureRandom().nextBytes(bytes);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }

    // ── Authorization URL con response_mode=form_post ─────────────────────────

    public static String buildAuthorizationUrl(String state) throws Exception {
        return OIDCConfig.AUTH_ENDPOINT
                + "?response_type=" + URLEncoder.encode(OIDCConfig.RESPONSE_TYPE, "UTF-8")
                + "&response_mode=" + URLEncoder.encode(OIDCConfig.RESPONSE_MODE, "UTF-8")
                + "&client_id="     + URLEncoder.encode(OIDCConfig.CLIENT_ID, "UTF-8")
                + "&redirect_uri="  + URLEncoder.encode(OIDCConfig.REDIRECT_URI, "UTF-8")
                + "&scope="         + URLEncoder.encode(OIDCConfig.SCOPES, "UTF-8")
                + "&state="         + URLEncoder.encode(state, "UTF-8")
                + "&nonce="         + URLEncoder.encode(generateState(), "UTF-8");
    }

    // ── Parsear claims del id_token (JWT) sin llamar a WSO2 IS ───────────────

    public static OIDCUser parseIdToken(String idToken) throws Exception {
        SignedJWT jwt = SignedJWT.parse(idToken);
        JWTClaimsSet claims = jwt.getJWTClaimsSet();

        OIDCUser user = new OIDCUser();
        user.setSub(              getStr(claims, "sub"));
        user.setName(             getStr(claims, "name"));
        user.setEmail(            getStr(claims, "email"));
        user.setPreferredUsername(getStr(claims, "preferred_username"));
        user.setMemberOf(         getStr(claims, "member_of"));
        user.setWindowsId(        getStr(claims, "axa-windowsID"));

        LOG.debug("Claims parseados del id_token: " + claims.toJSONObject());
        return user;
    }

    // ── Logout URL ────────────────────────────────────────────────────────────

    public static String buildLogoutUrl(String idToken) throws Exception {
        return OIDCConfig.LOGOUT_ENDPOINT
                + "?id_token_hint="            + URLEncoder.encode(idToken, "UTF-8")
                + "&post_logout_redirect_uri=" + URLEncoder.encode(OIDCConfig.POST_LOGOUT_REDIRECT, "UTF-8");
    }

    // ── Helper ────────────────────────────────────────────────────────────────

    private static String getStr(JWTClaimsSet claims, String key) {
        try {
            Object val = claims.getClaim(key);
            return val != null ? val.toString() : null;
        } catch (Exception e) {
            return null;
        }
    }
}
