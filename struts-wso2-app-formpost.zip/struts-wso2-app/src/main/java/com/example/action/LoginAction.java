package com.example.action;

import com.example.util.OIDCConfig;
import com.example.util.OIDCService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LoginAction extends Action {

    private static final Log LOG = LogFactory.getLog(LoginAction.class);

    @Override
    public ActionForward execute(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response) throws Exception {

        HttpSession session = request.getSession(true);

        String state = OIDCService.generateState();
        session.setAttribute(OIDCConfig.SESSION_STATE, state);

        String authUrl = OIDCService.buildAuthorizationUrl(state);
        LOG.info("Redirigiendo a WSO2 IS: " + authUrl);

        response.sendRedirect(authUrl);
        return null;
    }
}
