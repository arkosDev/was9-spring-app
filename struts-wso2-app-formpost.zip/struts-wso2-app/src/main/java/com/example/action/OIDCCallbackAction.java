package com.example.action;

import com.example.model.OIDCUser;
import com.example.util.OIDCConfig;
import com.example.util.OIDCService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * OIDCCallbackAction - form_post mode
 *
 * WSO2 IS hace un POST a esta URL con los tokens como parámetros.
 * No se hace ninguna llamada HTTP a WSO2 IS desde aquí.
 */
public class OIDCCallbackAction extends Action {

    private static final Log LOG = LogFactory.getLog(OIDCCallbackAction.class);

    @Override
    public ActionForward execute(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response) throws Exception {

        HttpSession session = request.getSession(false);

        // ── 1. Validar state (CSRF) ───────────────────────────────────────────
        String returnedState = request.getParameter("state");
        String savedState    = session != null
                ? (String) session.getAttribute(OIDCConfig.SESSION_STATE)
                : null;

        if (returnedState == null || !returnedState.equals(savedState)) {
            LOG.warn("State inválido. Posible ataque CSRF.");
            if (session != null) session.invalidate();
            request.setAttribute("errorMsg", "Sesión inválida. Por favor inicia sesión nuevamente.");
            return mapping.findForward("error");
        }

        // ── 2. Verificar error del IdP ────────────────────────────────────────
        String error = request.getParameter("error");
        if (error != null) {
            LOG.warn("Error del IdP: " + error);
            if (session != null) session.invalidate();
            request.setAttribute("errorMsg", "Error de autenticación: " + error);
            return mapping.findForward("error");
        }

        // ── 3. Obtener tokens del POST (WSO2 IS los manda directo) ────────────
        String idToken      = request.getParameter("id_token");
        String accessToken  = request.getParameter("access_token");

        if (idToken == null || idToken.isEmpty()) {
            LOG.error("No se recibió id_token en el POST de WSO2 IS.");
            if (session != null) session.invalidate();
            request.setAttribute("errorMsg", "No se recibió token del IdP.");
            return mapping.findForward("error");
        }

        // ── 4. Parsear claims del id_token sin llamar a WSO2 IS ──────────────
        OIDCUser user;
        try {
            user = OIDCService.parseIdToken(idToken);
        } catch (Exception e) {
            LOG.error("Error al parsear id_token", e);
            if (session != null) session.invalidate();
            request.setAttribute("errorMsg", "Token inválido.");
            return mapping.findForward("error");
        }

        // ── 5. Validar grupo autorizado ───────────────────────────────────────
        String memberOf  = user.getMemberOf();
        boolean autorizado = memberOf != null && (
                memberOf.contains("GRP_APP_ADRC_ADMIN") ||
                memberOf.contains("GRP_APP_ADRC_USER")
        );

        if (!autorizado) {
            LOG.warn("Usuario sin grupo autorizado: " + user.getSub() + " | memberOf: " + memberOf);
            if (session != null) session.invalidate();
            request.setAttribute("errorMsg", "No tienes permisos para acceder a esta aplicación.");
            return mapping.findForward("error");
        }

        // ── 6. Guardar en sesión ──────────────────────────────────────────────
        session = request.getSession(true);
        session.removeAttribute(OIDCConfig.SESSION_STATE);
        session.setAttribute(OIDCConfig.SESSION_USER,         user);
        session.setAttribute(OIDCConfig.SESSION_ID_TOKEN,     idToken);
        session.setAttribute(OIDCConfig.SESSION_ACCESS_TOKEN, accessToken);

        LOG.info("Usuario autenticado via form_post: " + user);

        return mapping.findForward("success");
    }
}
