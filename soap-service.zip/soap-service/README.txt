ESTRUCTURA
==========
soap-service/
  pom.xml
  src/main/java/com/empresa/soapservice/
    SoapServiceApplication.java   (clase @SpringBootApplication normal, no incluida aqui)
    config/CxfConfig.java
    endpoint/MyServiceImpl.java
  src/main/resources/
    application.properties
    wsdl/service.wsdl             <- aqui va el WSDL que te den

PASOS
=====
1. Copia tu archivo .wsdl real a src/main/resources/wsdl/service.wsdl
   (si trae XSDs importados por separado, tambien deben ir en esa carpeta
   respetando las rutas relativas que use el WSDL en sus <xsd:import>).

2. Ajusta en pom.xml el <wsdl> del cxf-codegen-plugin si el nombre de
   archivo es distinto a service.wsdl.

3. Corre:
     mvn generate-sources
   Esto genera en target/generated-sources/cxf las clases:
   - el SEI (interfaz con las operaciones, ej. MyServicePortType)
   - las clases de request/response (JAXB)
   Revisa esas clases para saber los nombres reales de metodos, service y
   namespace (varian segun tu WSDL).

4. Renombra/ajusta MyServiceImpl.java para que:
   - implemente el SEI generado real (no "MyServicePortType" placeholder)
   - el serviceName y targetNamespace coincidan EXACTO con el WSDL
   - implementes la logica de cada operacion

5. Ajusta CxfConfig.java si tu WSDL define mas de un servicio/puerto
   (un @Bean Endpoint por cada uno, con su propio publish("/ruta")).

6. mvn spring-boot:run
   El WSDL quedara expuesto (por defecto) en:
     http://localhost:8080/services/MyService?wsdl

NOTA
====
CXF regenera el nombre de paquete/clases segun el targetNamespace del WSDL,
asi que en cuanto corras wsdl2java es normal que tengas que renombrar
imports en MyServiceImpl.java para que compile.
