package com.empresa.soapservice.endpoint;

import com.empresa.soapservice.generated.MyServicePortType;
import jakarta.jws.WebService;
import org.springframework.stereotype.Component;

@Component
@WebService(
    serviceName = "MyService",
    targetNamespace = "http://tuempresa.com/wsdl",
    endpointInterface = "com.empresa.soapservice.generated.MyServicePortType"
)
public class MyServiceImpl implements MyServicePortType {

    // Una vez generado el SEI desde tu WSDL real, aqui implementas cada operacion.
    // El nombre de la clase, el serviceName, el targetNamespace y el
    // endpointInterface deben coincidir EXACTO con lo que wsdl2java genere.

}
