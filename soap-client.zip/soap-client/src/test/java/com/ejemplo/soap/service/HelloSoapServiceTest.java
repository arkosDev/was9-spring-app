package com.ejemplo.soap.service;

import com.ejemplo.soap.generated.SayHelloRequest;
import com.ejemplo.soap.generated.SayHelloResponse;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.ws.client.core.WebServiceTemplate;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class HelloSoapServiceTest {

    @Mock
    private WebServiceTemplate webServiceTemplate;

    @InjectMocks
    private HelloSoapService helloSoapService;

    @Test
    public void testSayHello_retornaRespuestaCorrecta() {
        SayHelloResponse mockResponse = new SayHelloResponse();
        mockResponse.setMessage("Hola, Arkos");

        when(webServiceTemplate.marshalSendAndReceive(any(SayHelloRequest.class)))
                .thenReturn(mockResponse);

        String resultado = helloSoapService.sayHello("Arkos");

        assertEquals("Hola, Arkos", resultado);
        verify(webServiceTemplate, times(1))
                .marshalSendAndReceive(any(SayHelloRequest.class));
    }

    @Test
    public void testSayHello_enviaNombreCorrecto() {
        SayHelloResponse mockResponse = new SayHelloResponse();
        mockResponse.setMessage("Hola, Test");

        when(webServiceTemplate.marshalSendAndReceive(any(SayHelloRequest.class)))
                .thenReturn(mockResponse);

        helloSoapService.sayHello("Test");

        verify(webServiceTemplate).marshalSendAndReceive(argThat(arg -> {
            SayHelloRequest req = (SayHelloRequest) arg;
            return "Test".equals(req.getName());
        }));
    }

    @Test(expected = RuntimeException.class)
    public void testSayHello_cuandoFallaElServicio_lanzaExcepcion() {
        when(webServiceTemplate.marshalSendAndReceive(any(SayHelloRequest.class)))
                .thenThrow(new RuntimeException("Servicio no disponible"));

        helloSoapService.sayHello("Arkos");
    }
}
