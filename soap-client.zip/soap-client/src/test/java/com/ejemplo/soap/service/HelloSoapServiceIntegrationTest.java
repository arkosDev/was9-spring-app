package com.ejemplo.soap.service;

import com.ejemplo.soap.SoapClientApp;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.ws.client.core.WebServiceTemplate;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@RunWith(SpringRunner.class)
@SpringBootTest(
        classes = {SoapClientApp.class},
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT
)
public class HelloSoapServiceIntegrationTest {

    @LocalServerPort
    private int port;

    @Autowired
    private Jaxb2Marshaller marshaller;

    private HelloSoapService service;

    @Before
    public void setUp() {
        WebServiceTemplate template = new WebServiceTemplate();
        template.setMarshaller(marshaller);
        template.setUnmarshaller(marshaller);
        template.setDefaultUri("http://localhost:" + port + "/ws/hello");

        service = new HelloSoapService();
        service.setWebServiceTemplate(template);
    }

    @Test
    public void testSayHello_integracion_retornaRespuestaReal() {
        String resultado = service.sayHello("Arkos");

        assertNotNull(resultado);
        assertEquals("Hola, Arkos", resultado);
    }

    @Test
    public void testSayHello_integracion_nombreVacio() {
        String resultado = service.sayHello("");

        assertNotNull(resultado);
        assertEquals("Hola, ", resultado);
    }
}
