package com.ejemplo.soap;

import com.ejemplo.soap.generated.SayHelloRequest;
import com.ejemplo.soap.generated.SayHelloResponse;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

@Endpoint
public class HelloEndpoint {

    private static final String NAMESPACE = "http://ejemplo.com/hello";

    @PayloadRoot(namespace = NAMESPACE, localPart = "SayHelloRequest")
    @ResponsePayload
    public SayHelloResponse sayHello(@RequestPayload SayHelloRequest request) {
        SayHelloResponse response = new SayHelloResponse();
        response.setMessage("Hola, " + request.getName());
        return response;
    }
}
