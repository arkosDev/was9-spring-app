package com.ejemplo.soap;

import com.ejemplo.soap.service.HelloSoapService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class SoapClientApp {

    public static void main(String[] args) {
        SpringApplication.run(SoapClientApp.class, args);
    }

    @Bean
    CommandLineRunner run(HelloSoapService service) {
        return args -> {
            String respuesta = service.sayHello("Arkos");
            System.out.println("Respuesta del servicio: " + respuesta);
        };
    }
}
