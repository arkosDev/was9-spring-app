package com.ejemplo.soap.service;

import com.ejemplo.soap.generated.SayHelloRequest;
import com.ejemplo.soap.generated.SayHelloResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ws.client.core.WebServiceTemplate;

@Service
public class HelloSoapService {

    @Autowired
    private WebServiceTemplate webServiceTemplate;

    public String sayHello(String name) {
        SayHelloRequest request = new SayHelloRequest();
        request.setName(name);

        SayHelloResponse response = (SayHelloResponse)
                webServiceTemplate.marshalSendAndReceive(request);

        return response.getMessage();
    }

    public void setWebServiceTemplate(WebServiceTemplate webServiceTemplate) {
        this.webServiceTemplate = webServiceTemplate;
    }
}
