package com.axa.seguros.autos.ws;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.ServletContext;
import org.apache.axis.MessageContext;
import org.apache.axis.transport.http.HTTPConstants;

/**
 * DummyService — ejemplo de Facade Axis 1.4 con integración Spring.
 *
 * PATRON:
 *   - Axis instancia esta clase directamente (no usa Spring para el WS)
 *   - El Facade obtiene beans de Spring via WebApplicationContextUtils
 *   - Igual al patrón usado en SolicitudPolizasWSFacade del SRV-007
 *
 * Para migrar un servicio real del SRV-007:
 *   1. Copiar esta clase
 *   2. Cambiar el nombre y el método dummy por los métodos reales
 *   3. Agregar los getBean() necesarios en el constructor
 *   4. Registrar el servicio en server-config.wsdd
 */
public class DummyServiceFacade {

    // Beans de Spring obtenidos en el constructor
    private final DummyService dummyService;

    public DummyServiceFacade() {
        // Obtener el WebApplicationContext de Spring desde el ServletContext
        // Axis provee acceso al MessageContext para llegar al ServletContext
        ServletContext sc = (ServletContext) MessageContext
                .getCurrentContext()
                .getProperty(HTTPConstants.MC_HTTP_SERVLETCONTEXT);

        WebApplicationContext ctx = WebApplicationContextUtils
                .getRequiredWebApplicationContext(sc);

        // Obtener beans de Spring — igual que en SolicitudPolizasWSFacade original
        this.dummyService = ctx.getBean("dummyService", DummyService.class);
    }

    /**
     * Método de ejemplo — retorna un String con el ID recibido.
     * Reemplazar por los métodos reales del SRV-007.
     */
    public String consultaDummy(Long solicitudID) {
        if (solicitudID == null) {
            throw new IllegalArgumentException("solicitudID es requerido");
        }
        return dummyService.consultar(solicitudID);
    }
}
