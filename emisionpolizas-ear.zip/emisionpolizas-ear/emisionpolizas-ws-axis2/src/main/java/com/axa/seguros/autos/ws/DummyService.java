package com.axa.seguros.autos.ws;

import org.springframework.stereotype.Service;

/**
 * DummyService — bean de Spring de ejemplo.
 * Reemplazar por los servicios reales migrados del SRV-007.
 */
@Service("dummyService")
public class DummyService {

    public String consultar(Long solicitudID) {
        // Lógica real aquí — BD, EJB, etc.
        return "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>"
             + "<Consulta><SolicitudID>" + solicitudID + "</SolicitudID></Consulta>";
    }
}
