package com.axa.seguros.autos.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * Configuración Spring del WAR Axis.
 * Aquí van los beans que necesitan los Facades del SRV-007:
 * DataSource, DAOs, Services, EJB proxies, etc.
 */
@Configuration
@ComponentScan(basePackages = "com.axa.seguros.autos")
public class AxisAppConfig {

    // Agregar aquí DataSource JNDI, beans de infraestructura, etc.
    // siguiendo el mismo patrón que el AppConfig del WAR JAX-WS

}
