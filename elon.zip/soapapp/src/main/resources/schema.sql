CREATE TABLE persona (
    id       INTEGER      NOT NULL GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    nombre   VARCHAR(100) NOT NULL,
    apellido VARCHAR(100) NOT NULL,
    email    VARCHAR(150)
);

INSERT INTO persona (nombre, apellido, email) VALUES ('Juan',  'Pérez',  'juan@example.com');
INSERT INTO persona (nombre, apellido, email) VALUES ('María', 'García', 'maria@example.com');
INSERT INTO persona (nombre, apellido, email) VALUES ('Carlos','López',  NULL);
