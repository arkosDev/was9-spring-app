package com.example.ws;

import com.example.model.Persona;
import com.example.service.PersonaService;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.annotation.Resource;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.servlet.ServletContext;
import javax.xml.ws.WebServiceContext;
import javax.xml.ws.handler.MessageContext;
import java.util.List;

@WebService(
    serviceName      = "PersonaService",
    portName         = "PersonaPort",
    targetNamespace  = "http://example.com/soap/persona"
)
public class PersonaWS {

    /*
     * WAS9 inyecta el WebServiceContext via @Resource.
     * Lo usamos para llegar al ServletContext y de ahí al ApplicationContext de Spring.
     */
    @Resource
    private WebServiceContext wsContext;

    private PersonaService getPersonaService() {
        ServletContext sc = (ServletContext) wsContext.getMessageContext()
                .get(MessageContext.SERVLET_CONTEXT);
        WebApplicationContext ctx = WebApplicationContextUtils
                .getRequiredWebApplicationContext(sc);
        return ctx.getBean(PersonaService.class);
    }

    // -------------------------------------------------------

    @WebMethod
    public Persona getPersonaById(@WebParam(name = "id") int id) {
        return getPersonaService().getPersonaById(id);
    }

    @WebMethod
    public List<Persona> getAllPersonas() {
        return getPersonaService().getAllPersonas();
    }

    @WebMethod
    public boolean savePersona(@WebParam(name = "persona") Persona persona) {
        return getPersonaService().savePersona(persona);
    }
}
