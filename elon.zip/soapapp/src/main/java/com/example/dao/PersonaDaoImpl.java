package com.example.dao;

import com.example.model.Persona;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
public class PersonaDaoImpl implements PersonaDao {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    private static final RowMapper<Persona> ROW_MAPPER = new RowMapper<Persona>() {
        @Override
        public Persona mapRow(ResultSet rs, int rowNum) throws SQLException {
            return new Persona(
                rs.getInt("id"),
                rs.getString("nombre"),
                rs.getString("apellido"),
                rs.getString("email")
            );
        }
    };

    @Override
    public Persona findById(int id) {
        List<Persona> lista = jdbcTemplate.query(
            "SELECT id, nombre, apellido, email FROM persona WHERE id = ?",
            ROW_MAPPER, id);
        return lista.isEmpty() ? null : lista.get(0);
    }

    @Override
    public List<Persona> findAll() {
        return jdbcTemplate.query(
            "SELECT id, nombre, apellido, email FROM persona ORDER BY id",
            ROW_MAPPER);
    }

    @Override
    public int save(Persona persona) {
        return jdbcTemplate.update(
            "INSERT INTO persona (nombre, apellido, email) VALUES (?, ?, ?)",
            persona.getNombre(), persona.getApellido(), persona.getEmail());
    }
}
