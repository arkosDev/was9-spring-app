package com.example.service;

import com.example.dao.PersonaDao;
import com.example.model.Persona;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PersonaServiceImpl implements PersonaService {

    private static final Logger log = LoggerFactory.getLogger(PersonaServiceImpl.class);

    @Autowired
    private PersonaDao personaDao;

    @Override
    public Persona getPersonaById(int id) {
        log.info("getPersonaById id={}", id);
        return personaDao.findById(id);
    }

    @Override
    public List<Persona> getAllPersonas() {
        log.info("getAllPersonas");
        return personaDao.findAll();
    }

    @Override
    public boolean savePersona(Persona persona) {
        log.info("savePersona nombre={}", persona.getNombre());
        return personaDao.save(persona) > 0;
    }
}
