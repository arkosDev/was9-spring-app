package com.example.filter;

import com.example.service.OidcService;
import com.example.util.OidcConstants;
import com.example.util.UserSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Map;

/**
 * Filtro que maneja el callback de WSO2 IS despues de que el usuario se autentica.
 *
 * Flujo:
 *  1. WSO2 redirige a /callback?code=XXX&state=YYY
 *  2. Este filtro intercepta, valida state, intercambia code por tokens,
 *     obtiene userinfo y guarda UserSession en HttpSession.
 *  3. Redirige al home privado de la app.
 */
public class OidcCallbackFilter implements Filter {

    private static final Logger log = LoggerFactory.getLogger(OidcCallbackFilter.class);

    private OidcService oidcService;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        WebApplicationContext ctx = WebApplicationContextUtils
                .getRequiredWebApplicationContext(filterConfig.getServletContext());
        this.oidcService = (OidcService) ctx.getBean("oidcService");
        log.info("OidcCallbackFilter inicializado");
    }

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest  request  = (HttpServletRequest)  req;
        HttpServletResponse response = (HttpServletResponse) res;
        HttpSession session = request.getSession(false);

        String code  = request.getParameter("code");
        String state = request.getParameter("state");
        String error = request.getParameter("error");

        // --- Error devuelto por WSO2 ---
        if (error != null) {
            log.warn("WSO2 devolvio error en callback: {} - {}", error,
                    request.getParameter("error_description"));
            response.sendRedirect(request.getContextPath() + "/pages/error.jsp?msg=" + error);
            return;
        }

        // --- Validaciones basicas ---
        if (code == null || state == null) {
            log.warn("Callback sin 'code' o 'state'");
            response.sendRedirect(request.getContextPath() + "/pages/error.jsp?msg=bad_callback");
            return;
        }

        if (session == null) {
            log.warn("Callback sin sesion activa (posible CSRF o sesion expirada)");
            response.sendRedirect(request.getContextPath() + "/login.do");
            return;
        }

        // --- Validar state anti-CSRF ---
        String savedState = (String) session.getAttribute(OidcConstants.SESSION_STATE);
        if (!state.equals(savedState)) {
            log.error("State no coincide. Posible CSRF. expected={} got={}", savedState, state);
            response.sendRedirect(request.getContextPath() + "/pages/error.jsp?msg=state_mismatch");
            return;
        }

        String codeVerifier = (String) session.getAttribute(OidcConstants.SESSION_CODE_VERIFIER);
        if (codeVerifier == null) {
            log.error("code_verifier no encontrado en sesion");
            response.sendRedirect(request.getContextPath() + "/pages/error.jsp?msg=no_verifier");
            return;
        }

        try {
            // --- Intercambiar code por tokens ---
            Map<String, String> tokens = oidcService.exchangeCodeForTokens(code, codeVerifier);
            String accessToken = tokens.get("access_token");
            String idToken     = tokens.get("id_token");

            if (accessToken == null) {
                throw new RuntimeException("Token endpoint no devolvio access_token");
            }

            // --- Obtener claims del usuario via userinfo ---
            Map<String, Object> userInfo = oidcService.getUserInfo(accessToken);

            // --- Construir UserSession ---
            UserSession userSession = new UserSession();
            userSession.setSub(            getString(userInfo, "sub"));
            userSession.setName(           getString(userInfo, "name"));
            userSession.setEmail(          getString(userInfo, "email"));
            userSession.setPreferredUsername(getString(userInfo, "preferred_username"));
            userSession.setWindowsId(      getString(userInfo, "axa-windowsID"));
            userSession.setMemberOf(       getString(userInfo, "member_of"));
            userSession.setAccessToken(accessToken);
            userSession.setIdToken(idToken);
            userSession.setAllClaims(userInfo);

            // --- Guardar en sesion ---
            session.setAttribute(OidcConstants.SESSION_USER, userSession);

            // Limpiar datos PKCE de la sesion
            session.removeAttribute(OidcConstants.SESSION_CODE_VERIFIER);
            session.removeAttribute(OidcConstants.SESSION_STATE);

            log.info("Usuario autenticado: sub={}, user={}", userSession.getSub(),
                    userSession.getPreferredUsername());

            // --- Redirigir al home privado ---
            response.sendRedirect(request.getContextPath() + "/secure/home.do");

        } catch (Exception e) {
            log.error("Error procesando callback OIDC", e);
            response.sendRedirect(request.getContextPath()
                    + "/pages/error.jsp?msg=callback_error");
        }
    }

    @Override
    public void destroy() {}

    private String getString(Map<String, Object> map, String key) {
        Object val = map.get(key);
        return val != null ? val.toString() : null;
    }
}
