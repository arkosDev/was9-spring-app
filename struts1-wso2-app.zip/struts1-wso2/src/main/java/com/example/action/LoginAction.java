package com.example.action;

import com.example.service.OidcService;
import com.example.util.OidcConstants;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Struts Action que inicia el flujo OIDC Authorization Code + PKCE.
 * Genera el code_verifier, state, y redirige al authorization endpoint de WSO2.
 *
 * Si el usuario ya esta autenticado, redirige directamente al home.
 */
public class LoginAction extends Action {

    private static final Logger log = LoggerFactory.getLogger(LoginAction.class);

    // Inyectado por Spring (ver applicationContext.xml)
    private OidcService oidcService;

    @Override
    public ActionForward execute(ActionMapping mapping, ActionForm form,
                                 HttpServletRequest request, HttpServletResponse response)
            throws Exception {

        HttpSession session = request.getSession(true);

        // Si ya esta autenticado, ir directo al home
        if (session.getAttribute(OidcConstants.SESSION_USER) != null) {
            response.sendRedirect(request.getContextPath() + "/secure/home.do");
            return null;
        }

        // Generar PKCE code_verifier + code_challenge
        String codeVerifier   = oidcService.generateCodeVerifier();
        String codeChallenge  = oidcService.generateCodeChallenge(codeVerifier);
        String state          = oidcService.generateState();

        // Guardar en sesion para validar en el callback
        session.setAttribute(OidcConstants.SESSION_CODE_VERIFIER, codeVerifier);
        session.setAttribute(OidcConstants.SESSION_STATE, state);

        // Construir URL de autorizacion
        String authUrl = oidcService.buildAuthorizationUrl(state, codeChallenge);
        log.debug("Redirigiendo a WSO2 IS: {}", authUrl);

        // Poner la URL en request para que redirect.jsp haga el redirect
        request.setAttribute("authorizationUrl", authUrl);
        return mapping.findForward("redirect");
    }

    public void setOidcService(OidcService oidcService) {
        this.oidcService = oidcService;
    }
}
