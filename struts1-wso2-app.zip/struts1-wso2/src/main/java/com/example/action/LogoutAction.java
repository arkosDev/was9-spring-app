package com.example.action;

import com.example.service.OidcService;
import com.example.util.OidcConstants;
import com.example.util.UserSession;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Struts Action para logout.
 * Invalida la sesion local y redirige al end_session endpoint de WSO2 IS
 * para cerrar tambien la sesion en el IdP (Single Logout).
 */
public class LogoutAction extends Action {

    private static final Logger log = LoggerFactory.getLogger(LogoutAction.class);

    private OidcService oidcService;

    @Override
    public ActionForward execute(ActionMapping mapping, ActionForm form,
                                 HttpServletRequest request, HttpServletResponse response)
            throws Exception {

        HttpSession session = request.getSession(false);
        String idToken = null;

        if (session != null) {
            UserSession userSession = (UserSession) session.getAttribute(OidcConstants.SESSION_USER);
            if (userSession != null) {
                idToken = userSession.getIdToken();
                log.info("Logout de usuario: {}", userSession.getPreferredUsername());
            }
            session.invalidate();
        }

        // Redirigir al end_session de WSO2 (cierra la sesion en el IdP)
        if (idToken != null) {
            String postLogoutUri = request.getScheme() + "://"
                    + request.getServerName() + ":" + request.getServerPort()
                    + request.getContextPath() + "/pages/loggedout.jsp";
            String logoutUrl = oidcService.buildLogoutUrl(idToken, postLogoutUri);
            response.sendRedirect(logoutUrl);
            return null;
        }

        // Si no hay idToken, mostrar pagina de logout local
        return mapping.findForward("loggedout");
    }

    public void setOidcService(OidcService oidcService) {
        this.oidcService = oidcService;
    }
}
