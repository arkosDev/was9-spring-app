<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%
    com.example.util.UserSession user =
        (com.example.util.UserSession) request.getAttribute("user");
    if (user == null) {
        response.sendRedirect(request.getContextPath() + "/login.do");
        return;
    }
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home - Autenticado via WSO2 IS</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }
        .card { background: white; padding: 30px; border-radius: 8px;
                box-shadow: 0 2px 6px rgba(0,0,0,0.15); max-width: 700px; }
        h1 { color: #333; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 10px; border: 1px solid #ddd; text-align: left; }
        th { background: #f0f0f0; }
        .logout-btn { display: inline-block; margin-top: 20px; padding: 10px 24px;
                      background: #c0392b; color: white; text-decoration: none;
                      border-radius: 4px; font-size: 14px; }
        .logout-btn:hover { background: #a93226; }
        .badge { background: #2980b9; color: white; padding: 2px 8px;
                 border-radius: 12px; font-size: 12px; }
    </style>
</head>
<body>
<div class="card">
    <h1>&#10003; Autenticado correctamente</h1>
    <p>Bienvenido, <strong><%= user.getName() != null ? user.getName() : user.getPreferredUsername() %></strong></p>
    <span class="badge">WSO2 IS - OIDC</span>

    <table>
        <tr>
            <th>Claim</th>
            <th>Valor</th>
        </tr>
        <tr><td>sub</td>             <td><%= safe(user.getSub()) %></td></tr>
        <tr><td>name</td>            <td><%= safe(user.getName()) %></td></tr>
        <tr><td>email</td>           <td><%= safe(user.getEmail()) %></td></tr>
        <tr><td>preferred_username</td><td><%= safe(user.getPreferredUsername()) %></td></tr>
        <tr><td>axa-windowsID</td>   <td><%= safe(user.getWindowsId()) %></td></tr>
        <tr><td>member_of</td>       <td><%= safe(user.getMemberOf()) %></td></tr>
    </table>

    <h3 style="margin-top:30px;">Todos los claims (userinfo)</h3>
    <table>
        <tr><th>Claim</th><th>Valor</th></tr>
        <%
            if (user.getAllClaims() != null) {
                for (java.util.Map.Entry<String, Object> entry : user.getAllClaims().entrySet()) {
        %>
        <tr>
            <td><%= entry.getKey() %></td>
            <td><%= entry.getValue() %></td>
        </tr>
        <%
                }
            }
        %>
    </table>

    <a href="<%= request.getContextPath() %>/logout.do" class="logout-btn">Cerrar sesion</a>
</div>
</body>
</html>
<%!
    private String safe(String s) {
        if (s == null) return "<em style='color:#999'>-</em>";
        return org.apache.commons.lang.StringEscapeUtils.escapeHtml(s);
    }
%>
