package com.example.action;

import com.example.service.OidcService;
import com.example.util.OidcConstants;
import com.example.util.UserSession;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LogoutAction extends Action {

    private static final Logger log = LoggerFactory.getLogger(LogoutAction.class);

    @Override
    public ActionForward execute(ActionMapping mapping, ActionForm form,
                                 HttpServletRequest request, HttpServletResponse response)
            throws Exception {

        HttpSession session = request.getSession(false);
        String idToken = null;

        if (session != null) {
            UserSession userSession = (UserSession) session.getAttribute(OidcConstants.SESSION_USER);
            if (userSession != null) {
                idToken = userSession.getIdToken();
                log.info("Logout de usuario: {}", userSession.getPreferredUsername());
            }
            session.invalidate();
        }

        if (idToken != null) {
            OidcService oidcService = getOidcService(request);
            String postLogoutUri = request.getScheme() + "://"
                    + request.getServerName() + ":" + request.getServerPort()
                    + request.getContextPath() + "/pages/loggedout.jsp";
            String logoutUrl = oidcService.buildLogoutUrl(idToken, postLogoutUri);
            response.sendRedirect(logoutUrl);
            return null;
        }

        return mapping.findForward("loggedout");
    }

    private OidcService getOidcService(HttpServletRequest request) {
        WebApplicationContext ctx = WebApplicationContextUtils
                .getRequiredWebApplicationContext(getServlet().getServletContext());
        return (OidcService) ctx.getBean("oidcService");
    }
}
